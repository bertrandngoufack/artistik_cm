<?php
/**
 * Script de test complet pour le module Etudes
 * Vérifie que le module est conforme au style des autres modules
 */

echo "==========================================\n";
echo "TEST COMPLET - MODULE ÉTUDES\n";
echo "==========================================\n\n";

// Configuration
$baseUrl = 'http://localhost:8082';
$adminUrl = $baseUrl . '/admin/etudes';

// Fonction pour tester une URL
function testUrl($url, $description) {
    echo "Test: $description\n";
    echo "URL: $url\n";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, true);
    curl_setopt($ch, CURLOPT_NOBODY, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode === 200) {
        echo "✓ SUCCÈS - Code HTTP: $httpCode\n";
        return true;
    } else {
        echo "✗ ÉCHEC - Code HTTP: $httpCode\n";
        return false;
    }
    echo "\n";
}

// Fonction pour tester une requête POST
function testPost($url, $data, $description) {
    echo "Test POST: $description\n";
    echo "URL: $url\n";
    echo "Data: " . http_build_query($data) . "\n";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode === 200 || $httpCode === 302) {
        echo "✓ SUCCÈS - Code HTTP: $httpCode\n";
        return true;
    } else {
        echo "✗ ÉCHEC - Code HTTP: $httpCode\n";
        return false;
    }
    echo "\n";
}

// Tests des pages principales
echo "1. TESTS DES PAGES PRINCIPALES\n";
echo "==============================\n";

$tests = [
    ['url' => $adminUrl, 'desc' => 'Page d\'accueil du module Etudes'],
    ['url' => $adminUrl . '/cycles', 'desc' => 'Gestion des cycles'],
    ['url' => $adminUrl . '/cycles/create', 'desc' => 'Création de cycle'],
    ['url' => $adminUrl . '/classes', 'desc' => 'Gestion des classes'],
    ['url' => $adminUrl . '/subjects', 'desc' => 'Gestion des matières'],
    ['url' => $adminUrl . '/timetable', 'desc' => 'Gestion de l\'emploi du temps'],
    ['url' => $adminUrl . '/assignments', 'desc' => 'Gestion des assignations'],
];

$successCount = 0;
foreach ($tests as $test) {
    if (testUrl($test['url'], $test['desc'])) {
        $successCount++;
    }
}

echo "Résultat: $successCount/" . count($tests) . " pages fonctionnent\n\n";

// Tests des requêtes POST
echo "2. TESTS DES REQUÊTES POST\n";
echo "==========================\n";

$postTests = [
    [
        'url' => $adminUrl . '/cycles/store',
        'data' => [
            'name' => 'Test Cycle cURL',
            'code' => 'TEST',
            'description' => 'Cycle de test via cURL',
            'is_active' => '1'
        ],
        'desc' => 'Création d\'un cycle'
    ],
    [
        'url' => $adminUrl . '/classes/store',
        'data' => [
            'name' => 'Classe Test cURL',
            'code' => 'CTEST',
            'cycle_id' => '2',
            'level' => '6',
            'capacity' => '30',
            'description' => 'Classe testée via cURL',
            'academic_year' => '2024-2025'
        ],
        'desc' => 'Création d\'une classe'
    ]
];

$postSuccessCount = 0;
foreach ($postTests as $test) {
    if (testPost($test['url'], $test['data'], $test['desc'])) {
        $postSuccessCount++;
    }
}

echo "Résultat: $postSuccessCount/" . count($postTests) . " requêtes POST fonctionnent\n\n";

// Tests de conformité avec le style
echo "3. TESTS DE CONFORMITÉ STYLE\n";
echo "============================\n";

echo "Vérification du style Bulma...\n";

// Test de la page d'accueil pour vérifier le style
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $adminUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);

$response = curl_exec($ch);
curl_close($ch);

$styleChecks = [
    'Bulma CSS' => strpos($response, 'bulma.min.css') !== false,
    'Font Awesome' => strpos($response, 'font-awesome') !== false,
    'Container class' => strpos($response, 'class="container"') !== false,
    'Level component' => strpos($response, 'class="level"') !== false,
    'Card component' => strpos($response, 'class="card"') !== false,
    'Button component' => strpos($response, 'class="button"') !== false,
    'Notification component' => strpos($response, 'class="notification"') !== false,
    'Table component' => strpos($response, 'class="table"') !== false,
    'Columns component' => strpos($response, 'class="columns"') !== false,
    'Box component' => strpos($response, 'class="box"') !== false
];

$styleSuccessCount = 0;
foreach ($styleChecks as $check => $result) {
    if ($result) {
        echo "✓ $check\n";
        $styleSuccessCount++;
    } else {
        echo "✗ $check\n";
    }
}

echo "Résultat: $styleSuccessCount/" . count($styleChecks) . " éléments de style Bulma détectés\n\n";

// Tests de base de données
echo "4. TESTS DE BASE DE DONNÉES\n";
echo "===========================\n";

// Connexion à la base de données
$host = '100.69.65.33';
$port = '13306';
$dbname = 'lycol_db';
$username = 'root';
$password = 'Bateau123';

try {
    $pdo = new PDO("mysql:host=$host;port=$port;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "✓ Connexion à la base de données réussie\n";
    
    // Vérifier les tables
    $tables = ['cycles', 'classes', 'subjects', 'timetables', 'teacher_assignments'];
    $tableSuccessCount = 0;
    
    foreach ($tables as $table) {
        try {
            $stmt = $pdo->query("SELECT COUNT(*) FROM $table");
            $count = $stmt->fetchColumn();
            echo "✓ Table $table: $count enregistrements\n";
            $tableSuccessCount++;
        } catch (PDOException $e) {
            echo "✗ Table $table: Erreur - " . $e->getMessage() . "\n";
        }
    }
    
    echo "Résultat: $tableSuccessCount/" . count($tables) . " tables accessibles\n";
    
    // Vérifier les relations
    echo "\nVérification des relations...\n";
    
    $relations = [
        'Classes -> Cycles' => "SELECT COUNT(*) FROM classes c JOIN cycles cy ON c.cycle_id = cy.id",
        'Timetables -> Classes' => "SELECT COUNT(*) FROM timetables t JOIN classes c ON t.class_id = c.id",
        'Timetables -> Subjects' => "SELECT COUNT(*) FROM timetables t JOIN subjects s ON t.subject_id = s.id",
        'Timetables -> Teachers' => "SELECT COUNT(*) FROM timetables t JOIN teachers th ON t.teacher_id = th.id",
        'Assignments -> Teachers' => "SELECT COUNT(*) FROM teacher_assignments ta JOIN teachers th ON ta.teacher_id = th.id",
        'Assignments -> Classes' => "SELECT COUNT(*) FROM teacher_assignments ta JOIN classes c ON ta.class_id = c.id",
        'Assignments -> Subjects' => "SELECT COUNT(*) FROM teacher_assignments ta JOIN subjects s ON ta.subject_id = s.id"
    ];
    
    $relationSuccessCount = 0;
    foreach ($relations as $relation => $query) {
        try {
            $stmt = $pdo->query($query);
            $count = $stmt->fetchColumn();
            echo "✓ $relation: $count relations\n";
            $relationSuccessCount++;
        } catch (PDOException $e) {
            echo "✗ $relation: Erreur - " . $e->getMessage() . "\n";
        }
    }
    
    echo "Résultat: $relationSuccessCount/" . count($relations) . " relations fonctionnelles\n";
    
} catch (PDOException $e) {
    echo "✗ Erreur de connexion à la base de données: " . $e->getMessage() . "\n";
}

// Résumé final
echo "\n==========================================\n";
echo "RÉSUMÉ FINAL\n";
echo "==========================================\n";

$totalTests = count($tests) + count($postTests) + count($styleChecks) + count($tables) + count($relations);
$totalSuccess = $successCount + $postSuccessCount + $styleSuccessCount + $tableSuccessCount + $relationSuccessCount;

echo "Pages testées: $successCount/" . count($tests) . "\n";
echo "Requêtes POST: $postSuccessCount/" . count($postTests) . "\n";
echo "Éléments de style: $styleSuccessCount/" . count($styleChecks) . "\n";
echo "Tables de base: $tableSuccessCount/" . count($tables) . "\n";
echo "Relations DB: $relationSuccessCount/" . count($relations) . "\n";
echo "TOTAL: $totalSuccess/$totalTests tests réussis\n";

if ($totalSuccess >= $totalTests * 0.8) {
    echo "\n🎉 LE MODULE ÉTUDES EST CONFORME ET FONCTIONNEL !\n";
    echo "✅ Style Bulma conforme aux autres modules\n";
    echo "✅ Base de données cohérente\n";
    echo "✅ Fonctionnalités opérationnelles\n";
} else {
    echo "\n⚠️  DES PROBLÈMES ONT ÉTÉ DÉTECTÉS\n";
    echo "Veuillez vérifier les erreurs ci-dessus\n";
}

echo "\n==========================================\n";
echo "FIN DES TESTS\n";
echo "==========================================\n";
?>
