<?php

namespace App\Models;

use CodeIgniter\Model;

class GradeModel extends Model
{
    protected $table = 'grades';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;

    protected $allowedFields = [
        'exam_id', 'student_id', 'marks_obtained', 'percentage', 'recorded_by'
    ];

    protected $useTimestamps = true;
    protected $dateFormat = 'datetime';
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    protected $validationRules = [
        'exam_id' => 'required|integer',
        'student_id' => 'required|integer',
        'marks_obtained' => 'required|numeric|greater_than_equal_to[0]',
        'percentage' => 'required|numeric|greater_than_equal_to[0]|less_than_equal_to[100]'
    ];

    protected $skipValidation = false;
    protected $cleanValidationRules = true;

    public function getGradesByExam($examId)
    {
        return $this->select('grades.*, students.first_name, students.last_name, students.matricule')
                   ->join('students', 'students.id = grades.student_id')
                   ->where('grades.exam_id', $examId)
                   ->orderBy('students.last_name', 'ASC')
                   ->findAll();
    }

    public function getGradesByStudent($studentId)
    {
        return $this->select('grades.*, exams.name as exam_name, subjects.name as subject_name')
                   ->join('exams', 'exams.id = grades.exam_id')
                   ->join('subjects', 'subjects.id = exams.subject_id')
                   ->where('grades.student_id', $studentId)
                   ->orderBy('exams.exam_date', 'DESC')
                   ->findAll();
    }

    public function getAverageScores()
    {
        return $this->select('subjects.name, AVG(grades.percentage) as average_score')
                   ->join('exams', 'exams.id = grades.exam_id')
                   ->join('subjects', 'subjects.id = exams.subject_id')
                   ->groupBy('subjects.id')
                   ->orderBy('average_score', 'DESC')
                   ->findAll();
    }

    public function getPassRates()
    {
        return $this->select('subjects.name, COUNT(CASE WHEN grades.percentage >= 50 THEN 1 END) as passed, COUNT(*) as total')
                   ->join('exams', 'exams.id = grades.exam_id')
                   ->join('subjects', 'subjects.id = exams.subject_id')
                   ->groupBy('subjects.id')
                   ->findAll();
    }

    public function getTopStudents($limit = 10)
    {
        return $this->select('students.first_name, students.last_name, students.matricule, AVG(grades.percentage) as average_score')
                   ->join('students', 'students.id = grades.student_id')
                   ->groupBy('students.id')
                   ->orderBy('average_score', 'DESC')
                   ->limit($limit)
                   ->findAll();
    }

    public function getGradeStats()
    {
        return [
            'total' => $this->countAllResults(),
            'average_score' => $this->select('AVG(percentage) as avg')->first()['avg'] ?? 0,
            'pass_rate' => $this->select('COUNT(CASE WHEN percentage >= 50 THEN 1 END) as passed, COUNT(*) as total')->first()
        ];
    }
}




