<?php

namespace App\Models;

use CodeIgniter\Model;

class SubjectModel extends Model
{
    protected $table = 'subjects';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;

    protected $allowedFields = [
        'name', 'code', 'description', 'coefficient', 'is_active'
    ];

    protected $useTimestamps = true;
    protected $dateFormat = 'datetime';
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    protected $validationRules = [
        'name' => 'required|min_length[2]|max_length[100]',
        'code' => 'required|min_length[2]|max_length[20]|is_unique[subjects.code,id,{id}]',
        'coefficient' => 'required|numeric|greater_than[0]'
    ];

    protected $skipValidation = false;
    protected $cleanValidationRules = true;

    public function getActiveSubjects()
    {
        return $this->where('is_active', 1)
                   ->orderBy('name', 'ASC')
                   ->findAll();
    }

    public function getSubjectsByClass($classId)
    {
        return $this->select('subjects.*')
                   ->join('class_subjects', 'class_subjects.subject_id = subjects.id')
                   ->where('class_subjects.class_id', $classId)
                   ->where('subjects.is_active', 1)
                   ->orderBy('subjects.name', 'ASC')
                   ->findAll();
    }
}




