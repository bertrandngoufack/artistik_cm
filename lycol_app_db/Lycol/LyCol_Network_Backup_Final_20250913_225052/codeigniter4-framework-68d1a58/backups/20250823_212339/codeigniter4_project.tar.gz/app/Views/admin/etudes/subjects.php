<?= $this->extend('admin/layout') ?>

<?= $this->section('content') ?>

<div class="container">
    <div class="section">
        <!-- En-tête -->
        <div class="level">
            <div class="level-left">
                <div class="level-item">
                    <h1 class="title">Gestion des Matières</h1>
                </div>
            </div>
            <div class="level-right">
                <div class="level-item">
                    <a href="<?= base_url('admin/etudes/subjects/create') ?>" class="button is-primary">
                        <span class="icon">
                            <i class="fas fa-plus"></i>
                        </span>
                        <span>Nouvelle Matière</span>
                    </a>
                </div>
            </div>
        </div>

        <!-- Statistiques -->
        <div class="columns is-multiline mb-5">
            <div class="column is-3">
                <div class="box has-background-primary has-text-white">
                    <div class="level">
                        <div class="level-left">
                            <div class="level-item">
                                <div>
                                    <p class="heading has-text-white">Total Matières</p>
                                    <p class="title has-text-white"><?= $total_subjects ?? 0 ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="level-right">
                            <div class="level-item">
                                <span class="icon has-text-white">
                                    <i class="fas fa-book"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="column is-3">
                <div class="box has-background-info has-text-white">
                    <div class="level">
                        <div class="level-left">
                            <div class="level-item">
                                <div>
                                    <p class="heading has-text-white">Matières Actives</p>
                                    <p class="title has-text-white"><?= $active_subjects ?? 0 ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="level-right">
                            <div class="level-item">
                                <span class="icon has-text-white">
                                    <i class="fas fa-check-circle"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="column is-3">
                <div class="box has-background-success has-text-white">
                    <div class="level">
                        <div class="level-left">
                            <div class="level-item">
                                <div>
                                    <p class="heading has-text-white">Assignations</p>
                                    <p class="title has-text-white"><?= $total_assignments ?? 0 ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="level-right">
                            <div class="level-item">
                                <span class="icon has-text-white">
                                    <i class="fas fa-chalkboard-teacher"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="column is-3">
                <div class="box has-background-warning has-text-white">
                    <div class="level">
                        <div class="level-left">
                            <div class="level-item">
                                <div>
                                    <p class="heading has-text-white">Emplois du Temps</p>
                                    <p class="title has-text-white"><?= $total_timetables ?? 0 ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="level-right">
                            <div class="level-item">
                                <span class="icon has-text-white">
                                    <i class="fas fa-calendar-alt"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filtres -->
        <div class="box">
            <div class="columns is-multiline">
                <div class="column is-4">
                    <div class="field">
                        <label class="label">Recherche</label>
                        <div class="control">
                            <input type="text" class="input" id="search" placeholder="Nom, code...">
                        </div>
                    </div>
                </div>
                <div class="column is-4">
                    <div class="field">
                        <label class="label">Statut</label>
                        <div class="control">
                            <div class="select is-fullwidth">
                                <select id="status_filter">
                                    <option value="">Tous les statuts</option>
                                    <option value="1">Actif</option>
                                    <option value="0">Inactif</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="column is-4">
                    <div class="field">
                        <label class="label">Tri</label>
                        <div class="control">
                            <div class="select is-fullwidth">
                                <select id="sort_filter">
                                    <option value="name">Nom</option>
                                    <option value="code">Code</option>
                                    <option value="created_at">Date création</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tableau des matières -->
        <div class="box">
            <div class="table-container">
                <table class="table is-fullwidth is-striped is-hoverable">
                    <thead>
                        <tr>
                            <th>Code</th>
                            <th>Nom</th>
                            <th>Description</th>
                            <th>Assignations</th>
                            <th>Emplois du Temps</th>
                            <th>Statut</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (isset($subjects) && is_array($subjects)): ?>
                            <?php foreach ($subjects as $subject): ?>
                                <tr>
                                    <td>
                                        <strong><?= esc($subject['code']) ?></strong>
                                    </td>
                                    <td><?= esc($subject['name']) ?></td>
                                    <td>
                                        <span class="has-text-grey">
                                            <?= esc(substr($subject['description'] ?? '', 0, 50)) ?>
                                            <?= (strlen($subject['description'] ?? '') > 50) ? '...' : '' ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="tag is-info">
                                            <?= esc($subject['assignment_count'] ?? 0) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="tag is-warning">
                                            <?= esc($subject['timetable_count'] ?? 0) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($subject['is_active']): ?>
                                            <span class="tag is-success">Actif</span>
                                        <?php else: ?>
                                            <span class="tag is-danger">Inactif</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="buttons are-small">
                                            <a href="<?= base_url('admin/etudes/subjects/view/' . $subject['id']) ?>" 
                                               class="button is-info" title="Voir">
                                                <span class="icon">
                                                    <i class="fas fa-eye"></i>
                                                </span>
                                            </a>
                                            <a href="<?= base_url('admin/etudes/subjects/edit/' . $subject['id']) ?>" 
                                               class="button is-warning" title="Modifier">
                                                <span class="icon">
                                                    <i class="fas fa-edit"></i>
                                                </span>
                                            </a>
                                            <button class="button is-danger" 
                                                    onclick="deleteSubject(<?= $subject['id'] ?>)" 
                                                    title="Supprimer">
                                                <span class="icon">
                                                    <i class="fas fa-trash"></i>
                                                </span>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="has-text-centered">
                                    <p class="has-text-grey">Aucune matière trouvée</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
// Filtres
document.getElementById('search').addEventListener('input', filterSubjects);
document.getElementById('status_filter').addEventListener('change', filterSubjects);
document.getElementById('sort_filter').addEventListener('change', sortSubjects);

function filterSubjects() {
    const search = document.getElementById('search').value.toLowerCase();
    const status = document.getElementById('status_filter').value;
    
    const rows = document.querySelectorAll('tbody tr');
    
    rows.forEach(row => {
        const code = row.cells[0].textContent.toLowerCase();
        const name = row.cells[1].textContent.toLowerCase();
        const statusCell = row.cells[5].textContent;
        
        const matchesSearch = code.includes(search) || name.includes(search);
        const matchesStatus = !status || 
            (status === '1' && statusCell.includes('Actif')) ||
            (status === '0' && statusCell.includes('Inactif'));
        
        row.style.display = (matchesSearch && matchesStatus) ? '' : 'none';
    });
}

function sortSubjects() {
    const sortBy = document.getElementById('sort_filter').value;
    const tbody = document.querySelector('tbody');
    const rows = Array.from(tbody.querySelectorAll('tr'));
    
    rows.sort((a, b) => {
        let aValue, bValue;
        
        switch(sortBy) {
            case 'name':
                aValue = a.cells[1].textContent.toLowerCase();
                bValue = b.cells[1].textContent.toLowerCase();
                break;
            case 'code':
                aValue = a.cells[0].textContent.toLowerCase();
                bValue = b.cells[0].textContent.toLowerCase();
                break;
            case 'created_at':
                // Pour l'instant, on trie par nom
                aValue = a.cells[1].textContent.toLowerCase();
                bValue = b.cells[1].textContent.toLowerCase();
                break;
            default:
                aValue = a.cells[1].textContent.toLowerCase();
                bValue = b.cells[1].textContent.toLowerCase();
        }
        
        return aValue.localeCompare(bValue);
    });
    
    // Réorganiser les lignes
    rows.forEach(row => tbody.appendChild(row));
}

function deleteSubject(subjectId) {
    if (confirm('Êtes-vous sûr de vouloir supprimer cette matière ?')) {
        fetch(`<?= base_url('admin/etudes/subjects/delete/') ?>${subjectId}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Erreur lors de la suppression: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Erreur:', error);
            alert('Erreur lors de la suppression');
        });
    }
}
</script>

<?= $this->endSection() ?>
