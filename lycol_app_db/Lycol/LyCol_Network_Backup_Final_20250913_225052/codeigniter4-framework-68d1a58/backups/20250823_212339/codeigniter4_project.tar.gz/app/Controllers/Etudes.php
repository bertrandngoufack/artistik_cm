<?php

namespace App\Controllers;

use App\Models\ClassModel;
use App\Models\SubjectModel;
use App\Models\CycleModel;
use App\Models\TimetableModel;
use App\Models\TeacherAssignmentModel;
use App\Models\TeacherModel;
use App\Models\StudentModel;

class Etudes extends BaseController
{
    protected $classModel;
    protected $subjectModel;
    protected $cycleModel;
    protected $timetableModel;
    protected $teacherAssignmentModel;
    protected $teacherModel;
    protected $studentModel;

    public function __construct()
    {
        $this->classModel = new ClassModel();
        $this->subjectModel = new SubjectModel();
        $this->cycleModel = new CycleModel();
        $this->timetableModel = new TimetableModel();
        $this->teacherAssignmentModel = new TeacherAssignmentModel();
        $this->teacherModel = new TeacherModel();
        $this->studentModel = new StudentModel();
    }

    public function index()
    {
        $data = [
            'title' => 'Module Études',
            'stats' => $this->getEtudesStats(),
            'classes' => $this->classModel->getActiveClasses(),
            'subjects' => $this->subjectModel->getActiveSubjects(),
            'cycles' => $this->cycleModel->getActiveCycles(),
            'recent_assignments' => $this->teacherAssignmentModel->getAssignmentStats()
        ];

        return view('admin/etudes/dashboard', $data);
    }

    // ==================== GESTION DES CYCLES ====================
    public function cycles()
    {
        $data = [
            'title' => 'Gestion des Cycles',
            'cycles' => $this->cycleModel->getCycleStats()
        ];

        return view('admin/etudes/cycles', $data);
    }

    public function createCycle()
    {
        $data = [
            'title' => 'Nouveau Cycle'
        ];

        return view('admin/etudes/create_cycle', $data);
    }

    public function storeCycle()
    {
        $rules = [
            'name' => 'required|min_length[2]|max_length[100]',
            'code' => 'required|min_length[2]|max_length[20]',
            'description' => 'max_length[500]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $cycleData = [
            'name' => $this->request->getPost('name'),
            'code' => $this->request->getPost('code'),
            'description' => $this->request->getPost('description'),
            'is_active' => 1
        ];

        if ($this->cycleModel->insert($cycleData)) {
            return redirect()->to('admin/etudes/cycles')->with('success', 'Cycle créé avec succès');
        } else {
            return redirect()->back()->withInput()->with('error', 'Erreur lors de la création');
        }
    }

    public function editCycle($id)
    {
        $cycle = $this->cycleModel->find($id);
        
        if (!$cycle) {
            return redirect()->to('admin/etudes/cycles')->with('error', 'Cycle non trouvé');
        }

        $data = [
            'title' => 'Modifier le Cycle',
            'cycle' => $cycle
        ];

        return view('admin/etudes/edit_cycle', $data);
    }

    public function updateCycle($id)
    {
        $rules = [
            'name' => 'required|min_length[2]|max_length[100]',
            'code' => 'required|min_length[2]|max_length[20]',
            'description' => 'max_length[500]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $cycleData = [
            'name' => $this->request->getPost('name'),
            'code' => $this->request->getPost('code'),
            'description' => $this->request->getPost('description')
        ];

        if ($this->cycleModel->update($id, $cycleData)) {
            return redirect()->to('admin/etudes/cycles')->with('success', 'Cycle mis à jour avec succès');
        } else {
            return redirect()->back()->withInput()->with('error', 'Erreur lors de la mise à jour');
        }
    }

    public function deleteCycle($id)
    {
        if ($this->cycleModel->delete($id)) {
            return redirect()->to('admin/etudes/cycles')->with('success', 'Cycle supprimé avec succès');
        } else {
            return redirect()->to('admin/etudes/cycles')->with('error', 'Erreur lors de la suppression');
        }
    }

    // ==================== GESTION DES CLASSES ====================
    public function classes()
    {
        $data = [
            'title' => 'Gestion des Classes',
            'classes' => $this->classModel->getActiveClasses(),
            'cycles' => $this->cycleModel->getActiveCycles(),
            'total_classes' => count($this->classModel->getActiveClasses()),
            'active_classes' => count($this->classModel->getActiveClasses()),
            'total_students' => $this->studentModel->getStudentStats()['total_students'] ?? 0,
            'total_cycles' => count($this->cycleModel->getActiveCycles())
        ];

        return view('admin/etudes/classes', $data);
    }

    public function createClass()
    {
        $data = [
            'title' => 'Nouvelle Classe',
            'cycles' => $this->cycleModel->getActiveCycles()
        ];

        return view('admin/etudes/create_class', $data);
    }

    public function storeClass()
    {
        $rules = [
            'name' => 'required|min_length[2]|max_length[100]',
            'code' => 'required|min_length[2]|max_length[20]',
            'cycle_id' => 'required|integer',
            'level' => 'required|integer|greater_than[0]',
            'capacity' => 'required|integer|greater_than[0]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $classData = [
            'name' => $this->request->getPost('name'),
            'code' => $this->request->getPost('code'),
            'cycle_id' => $this->request->getPost('cycle_id'),
            'level' => $this->request->getPost('level'),
            'capacity' => $this->request->getPost('capacity'),
            'description' => $this->request->getPost('description'),
            'is_active' => 1
        ];

        if ($this->classModel->createClass($classData)) {
            return redirect()->to('admin/etudes/classes')->with('success', 'Classe créée avec succès');
        } else {
            return redirect()->back()->withInput()->with('error', 'Erreur lors de la création');
        }
    }

    public function editClass($id)
    {
        $class = $this->classModel->getClassWithCycle($id);
        
        if (!$class) {
            return redirect()->to('admin/etudes/classes')->with('error', 'Classe non trouvée');
        }

        $data = [
            'title' => 'Modifier la Classe',
            'class' => $class,
            'cycles' => $this->cycleModel->getActiveCycles()
        ];

        return view('admin/etudes/edit_class', $data);
    }

    public function updateClass($id)
    {
        $rules = [
            'name' => 'required|min_length[2]|max_length[100]',
            'code' => 'required|min_length[2]|max_length[20]',
            'cycle_id' => 'required|integer',
            'level' => 'required|integer|greater_than[0]',
            'capacity' => 'required|integer|greater_than[0]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $classData = [
            'name' => $this->request->getPost('name'),
            'code' => $this->request->getPost('code'),
            'cycle_id' => $this->request->getPost('cycle_id'),
            'level' => $this->request->getPost('level'),
            'capacity' => $this->request->getPost('capacity'),
            'description' => $this->request->getPost('description')
        ];

        if ($this->classModel->updateClass($id, $classData)) {
            return redirect()->to('admin/etudes/classes')->with('success', 'Classe mise à jour avec succès');
        } else {
            return redirect()->back()->withInput()->with('error', 'Erreur lors de la mise à jour');
        }
    }

    public function deleteClass($id)
    {
        if ($this->classModel->delete($id)) {
            return redirect()->to('admin/etudes/classes')->with('success', 'Classe supprimée avec succès');
        } else {
            return redirect()->to('admin/etudes/classes')->with('error', 'Erreur lors de la suppression');
        }
    }

    public function viewClass($id)
    {
        $class = $this->classModel->getClassWithCycle($id);
        
        if (!$class) {
            return redirect()->to('admin/etudes/classes')->with('error', 'Classe non trouvée');
        }

        $data = [
            'title' => 'Détails de la Classe',
            'class' => $class,
            'students' => $this->studentModel->getStudentsByClass($id),
            'assignments' => $this->teacherAssignmentModel->getClassAssignments($id),
            'timetable' => $this->timetableModel->getClassTimetable($id)
        ];

        return view('admin/etudes/view_class', $data);
    }

    // ==================== GESTION DES MATIÈRES ====================
    public function subjects()
    {
        $data = [
            'title' => 'Gestion des Matières',
            'subjects' => $this->subjectModel->getActiveSubjects(),
            'total_subjects' => count($this->subjectModel->getActiveSubjects()),
            'active_subjects' => count($this->subjectModel->getActiveSubjects()),
            'total_assignments' => $this->teacherAssignmentModel->getAssignmentStats()['total_assignments'] ?? 0,
            'total_timetables' => $this->timetableModel->getTimetableStats()['total_timetables'] ?? 0
        ];

        return view('admin/etudes/subjects', $data);
    }

    public function createSubject()
    {
        $data = [
            'title' => 'Nouvelle Matière'
        ];

        return view('admin/etudes/create_subject', $data);
    }

    public function storeSubject()
    {
        $rules = [
            'name' => 'required|min_length[2]|max_length[100]',
            'code' => 'required|min_length[2]|max_length[20]',
            'coefficient' => 'required|numeric|greater_than[0]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $subjectData = [
            'name' => $this->request->getPost('name'),
            'code' => $this->request->getPost('code'),
            'coefficient' => $this->request->getPost('coefficient'),
            'description' => $this->request->getPost('description'),
            'is_active' => 1
        ];

        if ($this->subjectModel->insert($subjectData)) {
            return redirect()->to('admin/etudes/subjects')->with('success', 'Matière créée avec succès');
        } else {
            return redirect()->back()->withInput()->with('error', 'Erreur lors de la création');
        }
    }

    public function editSubject($id)
    {
        $subject = $this->subjectModel->find($id);
        
        if (!$subject) {
            return redirect()->to('admin/etudes/subjects')->with('error', 'Matière non trouvée');
        }

        $data = [
            'title' => 'Modifier la Matière',
            'subject' => $subject
        ];

        return view('admin/etudes/edit_subject', $data);
    }

    public function updateSubject($id)
    {
        $rules = [
            'name' => 'required|min_length[2]|max_length[100]',
            'code' => 'required|min_length[2]|max_length[20]',
            'coefficient' => 'required|numeric|greater_than[0]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $subjectData = [
            'name' => $this->request->getPost('name'),
            'code' => $this->request->getPost('code'),
            'coefficient' => $this->request->getPost('coefficient'),
            'description' => $this->request->getPost('description')
        ];

        if ($this->subjectModel->update($id, $subjectData)) {
            return redirect()->to('admin/etudes/subjects')->with('success', 'Matière mise à jour avec succès');
        } else {
            return redirect()->back()->withInput()->with('error', 'Erreur lors de la mise à jour');
        }
    }

    public function deleteSubject($id)
    {
        if ($this->subjectModel->delete($id)) {
            return redirect()->to('admin/etudes/subjects')->with('success', 'Matière supprimée avec succès');
        } else {
            return redirect()->to('admin/etudes/subjects')->with('error', 'Erreur lors de la suppression');
        }
    }

    // ==================== GESTION DES EMPLOIS DU TEMPS ====================
    public function timetable()
    {
        $data = [
            'title' => 'Emploi du Temps',
            'timetables' => $this->timetableModel->getActiveTimetables(),
            'classes' => $this->classModel->getActiveClasses(),
            'subjects' => $this->subjectModel->getActiveSubjects(),
            'teachers' => $this->teacherModel->getActiveTeachers(),
            'total_timetables' => count($this->timetableModel->getActiveTimetables()),
            'classes_covered' => $this->timetableModel->getTimetableStats()['classes_covered'] ?? 0,
            'teachers_involved' => $this->timetableModel->getTimetableStats()['teachers_involved'] ?? 0,
            'subjects_covered' => $this->timetableModel->getTimetableStats()['subjects_covered'] ?? 0
        ];

        return view('admin/etudes/timetable', $data);
    }

    public function createTimetable()
    {
        $data = [
            'title' => 'Nouveau Cours',
            'classes' => $this->classModel->getActiveClasses(),
            'subjects' => $this->subjectModel->getActiveSubjects(),
            'teachers' => $this->teacherModel->getActiveTeachers()
        ];

        return view('admin/etudes/create_timetable', $data);
    }

    public function storeTimetable()
    {
        $rules = [
            'class_id' => 'required|integer',
            'day_of_week' => 'required|integer|greater_than[0]|less_than[7]',
            'start_time' => 'required',
            'end_time' => 'required',
            'subject_id' => 'required|integer',
            'teacher_id' => 'integer'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $timetableData = [
            'class_id' => $this->request->getPost('class_id'),
            'day_of_week' => $this->request->getPost('day_of_week'),
            'start_time' => $this->request->getPost('start_time'),
            'end_time' => $this->request->getPost('end_time'),
            'subject_id' => $this->request->getPost('subject_id'),
            'teacher_id' => $this->request->getPost('teacher_id') ?: null,
            'room' => $this->request->getPost('room'),
            'is_active' => 1
        ];

        // Vérifier les conflits
        if ($this->timetableModel->checkConflicts(
            $timetableData['class_id'], 
            $timetableData['day_of_week'], 
            $timetableData['start_time'], 
            $timetableData['end_time']
        )) {
            return redirect()->back()->withInput()->with('error', 'Conflit d\'emploi du temps détecté');
        }

        if ($timetableData['teacher_id'] && $this->timetableModel->checkTeacherConflicts(
            $timetableData['teacher_id'], 
            $timetableData['day_of_week'], 
            $timetableData['start_time'], 
            $timetableData['end_time']
        )) {
            return redirect()->back()->withInput()->with('error', 'L\'enseignant a déjà un cours à cette heure');
        }

        if ($this->timetableModel->insert($timetableData)) {
            return redirect()->to('admin/etudes/timetable')->with('success', 'Cours ajouté avec succès');
        } else {
            return redirect()->back()->withInput()->with('error', 'Erreur lors de l\'ajout');
        }
    }

    public function editTimetable($id)
    {
        $timetable = $this->timetableModel->find($id);
        
        if (!$timetable) {
            return redirect()->to('admin/etudes/timetable')->with('error', 'Cours non trouvé');
        }

        $data = [
            'title' => 'Modifier le Cours',
            'timetable' => $timetable,
            'classes' => $this->classModel->getActiveClasses(),
            'subjects' => $this->subjectModel->getActiveSubjects(),
            'teachers' => $this->teacherModel->getActiveTeachers()
        ];

        return view('admin/etudes/edit_timetable', $data);
    }

    public function updateTimetable($id)
    {
        $rules = [
            'class_id' => 'required|integer',
            'day_of_week' => 'required|integer|greater_than[0]|less_than[7]',
            'start_time' => 'required',
            'end_time' => 'required',
            'subject_id' => 'required|integer',
            'teacher_id' => 'integer'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $timetableData = [
            'class_id' => $this->request->getPost('class_id'),
            'day_of_week' => $this->request->getPost('day_of_week'),
            'start_time' => $this->request->getPost('start_time'),
            'end_time' => $this->request->getPost('end_time'),
            'subject_id' => $this->request->getPost('subject_id'),
            'teacher_id' => $this->request->getPost('teacher_id') ?: null,
            'room' => $this->request->getPost('room')
        ];

        // Vérifier les conflits
        if ($this->timetableModel->checkConflicts(
            $timetableData['class_id'], 
            $timetableData['day_of_week'], 
            $timetableData['start_time'], 
            $timetableData['end_time'],
            $id
        )) {
            return redirect()->back()->withInput()->with('error', 'Conflit d\'emploi du temps détecté');
        }

        if ($timetableData['teacher_id'] && $this->timetableModel->checkTeacherConflicts(
            $timetableData['teacher_id'], 
            $timetableData['day_of_week'], 
            $timetableData['start_time'], 
            $timetableData['end_time'],
            $id
        )) {
            return redirect()->back()->withInput()->with('error', 'L\'enseignant a déjà un cours à cette heure');
        }

        if ($this->timetableModel->update($id, $timetableData)) {
            return redirect()->to('admin/etudes/timetable')->with('success', 'Cours mis à jour avec succès');
        } else {
            return redirect()->back()->withInput()->with('error', 'Erreur lors de la mise à jour');
        }
    }

    public function deleteTimetable($id)
    {
        if ($this->timetableModel->delete($id)) {
            return redirect()->to('admin/etudes/timetable')->with('success', 'Cours supprimé avec succès');
        } else {
            return redirect()->to('admin/etudes/timetable')->with('error', 'Erreur lors de la suppression');
        }
    }

    public function viewClassTimetable($classId)
    {
        $class = $this->classModel->getClassWithCycle($classId);
        
        if (!$class) {
            return redirect()->to('admin/etudes/timetable')->with('error', 'Classe non trouvée');
        }

        $data = [
            'title' => 'Emploi du Temps - ' . $class['name'],
            'class' => $class,
            'timetable' => $this->timetableModel->getClassTimetable($classId)
        ];

        return view('admin/etudes/view_class_timetable', $data);
    }

    // ==================== GESTION DES ASSIGNATIONS ====================
    public function assignments()
    {
        $data = [
            'title' => 'Assignations Enseignants',
            'assignments' => $this->teacherAssignmentModel->getActiveAssignments(),
            'classes' => $this->classModel->getActiveClasses(),
            'subjects' => $this->subjectModel->getActiveSubjects(),
            'teachers' => $this->teacherModel->getActiveTeachers(),
            'cycles' => $this->cycleModel->getActiveCycles(),
            'total_assignments' => count($this->teacherAssignmentModel->getActiveAssignments()),
            'teachers_assigned' => $this->teacherAssignmentModel->getAssignmentStats()['teachers_assigned'] ?? 0,
            'classes_covered' => $this->teacherAssignmentModel->getAssignmentStats()['classes_covered'] ?? 0,
            'subjects_covered' => $this->teacherAssignmentModel->getAssignmentStats()['subjects_covered'] ?? 0
        ];

        return view('admin/etudes/assignments', $data);
    }

    public function createAssignment()
    {
        $data = [
            'title' => 'Nouvelle Assignation',
            'classes' => $this->classModel->getActiveClasses(),
            'subjects' => $this->subjectModel->getActiveSubjects(),
            'teachers' => $this->teacherModel->getActiveTeachers()
        ];

        return view('admin/etudes/create_assignment', $data);
    }

    public function storeAssignment()
    {
        $rules = [
            'teacher_id' => 'required|integer',
            'class_id' => 'required|integer',
            'subject_id' => 'required|integer',
            'academic_year' => 'required|min_length[9]|max_length[9]',
            'is_principal' => 'integer'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $assignmentData = [
            'teacher_id' => $this->request->getPost('teacher_id'),
            'class_id' => $this->request->getPost('class_id'),
            'subject_id' => $this->request->getPost('subject_id'),
            'academic_year' => $this->request->getPost('academic_year'),
            'is_principal' => $this->request->getPost('is_principal') ? 1 : 0,
            'is_active' => 1
        ];

        // Vérifier si l'assignation existe déjà
        if ($this->teacherAssignmentModel->isTeacherAssigned(
            $assignmentData['teacher_id'],
            $assignmentData['class_id'],
            $assignmentData['subject_id'],
            $assignmentData['academic_year']
        )) {
            return redirect()->back()->withInput()->with('error', 'Cette assignation existe déjà');
        }

        if ($this->teacherAssignmentModel->insert($assignmentData)) {
            return redirect()->to('admin/etudes/assignments')->with('success', 'Assignation créée avec succès');
        } else {
            return redirect()->back()->withInput()->with('error', 'Erreur lors de la création');
        }
    }

    public function editAssignment($id)
    {
        $assignment = $this->teacherAssignmentModel->find($id);
        
        if (!$assignment) {
            return redirect()->to('admin/etudes/assignments')->with('error', 'Assignation non trouvée');
        }

        $data = [
            'title' => 'Modifier l\'Assignation',
            'assignment' => $assignment,
            'classes' => $this->classModel->getActiveClasses(),
            'subjects' => $this->subjectModel->getActiveSubjects(),
            'teachers' => $this->teacherModel->getActiveTeachers()
        ];

        return view('admin/etudes/edit_assignment', $data);
    }

    public function updateAssignment($id)
    {
        $rules = [
            'teacher_id' => 'required|integer',
            'class_id' => 'required|integer',
            'subject_id' => 'required|integer',
            'academic_year' => 'required|min_length[9]|max_length[9]',
            'is_principal' => 'integer'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $assignmentData = [
            'teacher_id' => $this->request->getPost('teacher_id'),
            'class_id' => $this->request->getPost('class_id'),
            'subject_id' => $this->request->getPost('subject_id'),
            'academic_year' => $this->request->getPost('academic_year'),
            'is_principal' => $this->request->getPost('is_principal') ? 1 : 0
        ];

        // Vérifier si l'assignation existe déjà
        if ($this->teacherAssignmentModel->isTeacherAssigned(
            $assignmentData['teacher_id'],
            $assignmentData['class_id'],
            $assignmentData['subject_id'],
            $assignmentData['academic_year'],
            $id
        )) {
            return redirect()->back()->withInput()->with('error', 'Cette assignation existe déjà');
        }

        if ($this->teacherAssignmentModel->update($id, $assignmentData)) {
            return redirect()->to('admin/etudes/assignments')->with('success', 'Assignation mise à jour avec succès');
        } else {
            return redirect()->back()->withInput()->with('error', 'Erreur lors de la mise à jour');
        }
    }

    public function deleteAssignment($id)
    {
        if ($this->teacherAssignmentModel->delete($id)) {
            return redirect()->to('admin/etudes/assignments')->with('success', 'Assignation supprimée avec succès');
        } else {
            return redirect()->to('admin/etudes/assignments')->with('error', 'Erreur lors de la suppression');
        }
    }

    // ==================== MÉTHODES PRIVÉES ====================
    private function getEtudesStats()
    {
        return [
            'totalClasses' => count($this->classModel->getActiveClasses()),
            'totalSubjects' => count($this->subjectModel->getActiveSubjects()),
            'totalCycles' => count($this->cycleModel->getActiveCycles()),
            'totalTeachers' => count($this->teacherModel->getActiveTeachers()),
            'classesByLevel' => [],
            'cyclesStats' => $this->cycleModel->getActiveCycles()
        ];
    }
}




