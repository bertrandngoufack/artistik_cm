<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container">
  <div class="hero is-primary is-bold">
    <div class="hero-body">
      <div class="container">
        <h1 class="title is-1">
          <span class="icon"><i class="fas fa-graduation-cap"></i></span>
          Bienvenue sur KISSAI SCHOOL
        </h1>
        <h2 class="subtitle">
          Solution complète de gestion scolaire adaptée au système éducatif camerounais. Interface moderne avec <strong>Bulma CSS</strong>.
        </h2>
        <div class="buttons">
          <a class="button is-light is-large" href="<?= base_url('auth/login') ?>">
            <span class="icon"><i class="fas fa-sign-in-alt"></i></span>
            <span>Connexion</span>
          </a>
          <a class="button is-info is-large" href="<?= base_url('auth/parents') ?>">
            <span class="icon"><i class="fas fa-users"></i></span>
            <span>Espace Parents</span>
          </a>
        </div>
      </div>
    </div>
  </div>

  <div class="columns is-multiline mt-6">
    <div class="column is-4">
      <div class="card">
        <div class="card-content">
          <div class="media">
            <div class="media-left">
              <span class="icon is-large has-text-info">
                <i class="fas fa-file-code fa-2x"></i>
              </span>
            </div>
            <div class="media-content">
              <p class="title is-4">Vues</p>
              <p class="subtitle is-6">Templates et Layouts</p>
            </div>
          </div>
          <div class="content">
            Les templates se trouvent dans <code>app/Views/</code>. Ce fichier étend un layout Bulma.
            <br>
            <small class="has-text-grey">Layout global avec navigation responsive</small>
          </div>
        </div>
      </div>
    </div>
    
    <div class="column is-4">
      <div class="card">
        <div class="card-content">
          <div class="media">
            <div class="media-left">
              <span class="icon is-large has-text-success">
                <i class="fas fa-cogs fa-2x"></i>
              </span>
            </div>
            <div class="media-content">
              <p class="title is-4">Contrôleurs</p>
              <p class="subtitle is-6">Logique métier</p>
            </div>
          </div>
          <div class="content">
            Le contrôleur <code>Home</code> retourne cette vue via <code>return view('home')</code>.
            <br>
            <small class="has-text-grey">Architecture MVC respectée</small>
          </div>
        </div>
      </div>
    </div>
    
    <div class="column is-4">
      <div class="card">
        <div class="card-content">
          <div class="media">
            <div class="media-left">
              <span class="icon is-large has-text-warning">
                <i class="fas fa-folder-open fa-2x"></i>
              </span>
            </div>
            <div class="media-content">
              <p class="title is-4">Assets</p>
              <p class="subtitle is-6">CSS et JavaScript</p>
            </div>
          </div>
          <div class="content">
            Bulma est chargé depuis <code>public/assets/bulma</code> (CSS/JS) pour un fonctionnement hors-ligne.
            <br>
            <small class="has-text-grey">Framework CSS moderne et responsive</small>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="notification is-info is-light mt-6">
    <div class="content">
      <h4 class="title is-4">
        <span class="icon"><i class="fas fa-info-circle"></i></span>
        Configuration actuelle
      </h4>
      <ul>
        <li><strong>PHP :</strong> <?= PHP_VERSION ?></li>
        <li><strong>CodeIgniter :</strong> <?= CodeIgniter\CodeIgniter::CI_VERSION ?></li>
        <li><strong>Framework CSS :</strong> Bulma 0.9.4</li>
        <li><strong>Serveur :</strong> http://localhost:8081</li>
      </ul>
    </div>
  </div>
</div>
<?= $this->endSection() ?>



