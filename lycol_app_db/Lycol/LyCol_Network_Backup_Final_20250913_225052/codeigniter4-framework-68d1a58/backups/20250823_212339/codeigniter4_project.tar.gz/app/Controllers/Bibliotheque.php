<?php

namespace App\Controllers;

use App\Models\BookModel;
use App\Models\LoanModel;

class Bibliotheque extends BaseController
{
    protected $bookModel;
    protected $loanModel;

    public function __construct()
    {
        $this->bookModel = new BookModel();
        $this->loanModel = new LoanModel();
    }

    public function index()
    {
        $data = [
            'title' => 'Module Bibliothèque',
            'stats' => $this->getLibraryStats(),
            'recentLoans' => $this->loanModel->getRecentLoans(10)
        ];

        return view('admin/bibliotheque/dashboard', $data);
    }

    public function books()
    {
        $data = [
            'title' => 'Gestion des Livres',
            'books' => $this->bookModel->getBooksPaginated(),
            'pager' => $this->bookModel->getBooksPager()
        ];

        return view('admin/bibliotheque/books', $data);
    }

    public function createBook()
    {
        $data = [
            'title' => 'Nouveau Livre'
        ];

        return view('admin/bibliotheque/create_book', $data);
    }

    public function storeBook()
    {
        $rules = [
            'title' => 'required|min_length[2]|max_length[200]',
            'author' => 'required|min_length[2]|max_length[100]',
            'isbn' => 'required|min_length[10]|max_length[20]',
            'copies' => 'required|integer|greater_than[0]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $bookData = [
            'title' => $this->request->getPost('title'),
            'author' => $this->request->getPost('author'),
            'isbn' => $this->request->getPost('isbn'),
            'copies' => $this->request->getPost('copies'),
            'is_active' => 1
        ];

        if ($this->bookModel->insert($bookData)) {
            return redirect()->to('admin/bibliotheque/books')->with('success', 'Livre ajouté avec succès');
        } else {
            return redirect()->back()->withInput()->with('error', 'Erreur lors de l\'ajout');
        }
    }

    public function editBook($id)
    {
        $book = $this->bookModel->find($id);
        
        if (!$book) {
            return redirect()->to('admin/bibliotheque/books')->with('error', 'Livre non trouvé');
        }

        $data = [
            'title' => 'Modifier le Livre',
            'book' => $book
        ];

        return view('admin/bibliotheque/edit_book', $data);
    }

    public function updateBook($id)
    {
        $rules = [
            'title' => 'required|min_length[2]|max_length[200]',
            'author' => 'required|min_length[2]|max_length[100]',
            'isbn' => 'required|min_length[10]|max_length[20]',
            'copies' => 'required|integer|greater_than[0]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $bookData = [
            'title' => $this->request->getPost('title'),
            'author' => $this->request->getPost('author'),
            'isbn' => $this->request->getPost('isbn'),
            'copies' => $this->request->getPost('copies')
        ];

        if ($this->bookModel->update($id, $bookData)) {
            return redirect()->to('admin/bibliotheque/books')->with('success', 'Livre mis à jour avec succès');
        } else {
            return redirect()->back()->withInput()->with('error', 'Erreur lors de la mise à jour');
        }
    }

    public function deleteBook($id)
    {
        if ($this->bookModel->delete($id)) {
            return redirect()->to('admin/bibliotheque/books')->with('success', 'Livre supprimé avec succès');
        } else {
            return redirect()->to('admin/bibliotheque/books')->with('error', 'Erreur lors de la suppression');
        }
    }

    public function loans()
    {
        $data = [
            'title' => 'Gestion des Emprunts',
            'loans' => $this->loanModel->getLoansPaginated(),
            'pager' => $this->loanModel->getLoansPager()
        ];

        return view('admin/bibliotheque/loans', $data);
    }

    public function createLoan()
    {
        $data = [
            'title' => 'Nouvel Emprunt',
            'books' => $this->bookModel->getAvailableBooks()
        ];

        return view('admin/bibliotheque/create_loan', $data);
    }

    public function storeLoan()
    {
        $rules = [
            'book_id' => 'required|integer',
            'borrower_name' => 'required|min_length[2]|max_length[100]',
            'loan_date' => 'required|valid_date',
            'due_date' => 'required|valid_date'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $loanData = [
            'book_id' => $this->request->getPost('book_id'),
            'borrower_name' => $this->request->getPost('borrower_name'),
            'loan_date' => $this->request->getPost('loan_date'),
            'due_date' => $this->request->getPost('due_date'),
            'status' => 'BORROWED'
        ];

        if ($this->loanModel->insert($loanData)) {
            return redirect()->to('admin/bibliotheque/loans')->with('success', 'Emprunt enregistré avec succès');
        } else {
            return redirect()->back()->withInput()->with('error', 'Erreur lors de l\'enregistrement');
        }
    }

    public function returnLoan($id)
    {
        $loan = $this->loanModel->find($id);
        
        if (!$loan) {
            return redirect()->to('admin/bibliotheque/loans')->with('error', 'Emprunt non trouvé');
        }

        $updateData = [
            'return_date' => date('Y-m-d'),
            'status' => 'RETURNED'
        ];

        if ($this->loanModel->update($id, $updateData)) {
            return redirect()->to('admin/bibliotheque/loans')->with('success', 'Livre retourné avec succès');
        } else {
            return redirect()->to('admin/bibliotheque/loans')->with('error', 'Erreur lors du retour');
        }
    }

    public function members()
    {
        $data = [
            'title' => 'Gestion des Membres',
            'members' => $this->loanModel->getMembers()
        ];

        return view('admin/bibliotheque/members', $data);
    }

    private function getLibraryStats()
    {
        return [
            'totalBooks' => $this->bookModel->countAllResults(),
            'totalLoans' => $this->loanModel->countAllResults(),
            'activeLoans' => $this->loanModel->where('status', 'BORROWED')->countAllResults(),
            'overdueLoans' => $this->loanModel->getOverdueLoans()->count()
        ];
    }
}




