<?php

namespace App\Models;

use CodeIgniter\Model;

class SettingModel extends Model
{
    protected $table = 'settings';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $protectFields = true;
    protected $allowedFields = [
        'key',
        'value',
        'type',
        'description',
        'is_public',
        'created_at',
        'updated_at'
    ];

    // Dates
    protected $useTimestamps = true;
    protected $dateFormat = 'datetime';
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    // Validation
    protected $validationRules = [
        'key' => 'required|min_length[3]|max_length[100]|is_unique[settings.key,id,{id}]',
        'value' => 'required',
        'type' => 'required|in_list[string,integer,float,boolean,json,text]',
        'description' => 'permit_empty|max_length[500]',
        'is_public' => 'permit_empty|in_list[0,1]'
    ];

    protected $validationMessages = [
        'key' => [
            'required' => 'La clé est requise',
            'min_length' => 'La clé doit contenir au moins 3 caractères',
            'max_length' => 'La clé ne peut pas dépasser 100 caractères',
            'is_unique' => 'Cette clé existe déjà'
        ],
        'value' => [
            'required' => 'La valeur est requise'
        ],
        'type' => [
            'required' => 'Le type est requis',
            'in_list' => 'Le type doit être string, integer, float, boolean, json ou text'
        ]
    ];

    protected $skipValidation = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks = true;
    protected $beforeInsert = ['beforeInsert'];
    protected $beforeUpdate = ['beforeUpdate'];

    protected function beforeInsert(array $data)
    {
        $data['data']['created_at'] = date('Y-m-d H:i:s');
        $data['data']['updated_at'] = date('Y-m-d H:i:s');
        return $data;
    }

    protected function beforeUpdate(array $data)
    {
        $data['data']['updated_at'] = date('Y-m-d H:i:s');
        return $data;
    }

    /**
     * Récupère une valeur de paramètre par sa clé
     */
    public function getValue($key, $default = null)
    {
        $setting = $this->where('key', $key)->first();
        
        if (!$setting) {
            return $default;
        }

        return $this->parseValue($setting['value'], $setting['type']);
    }

    /**
     * Définit une valeur de paramètre
     */
    public function setValue($key, $value, $type = 'string', $description = '', $isPublic = false)
    {
        $data = [
            'key' => $key,
            'value' => $this->formatValue($value, $type),
            'type' => $type,
            'description' => $description,
            'is_public' => $isPublic ? 1 : 0
        ];

        $existing = $this->where('key', $key)->first();
        
        if ($existing) {
            return $this->update($existing['id'], $data);
        } else {
            return $this->insert($data);
        }
    }

    /**
     * Récupère tous les paramètres publics
     */
    public function getPublicSettings()
    {
        $settings = $this->where('is_public', 1)->findAll();
        $result = [];
        
        foreach ($settings as $setting) {
            $result[$setting['key']] = $this->parseValue($setting['value'], $setting['type']);
        }
        
        return $result;
    }

    /**
     * Récupère les paramètres par groupe
     */
    public function getSettingsByGroup($group)
    {
        $settings = $this->like('key', $group . '.', 'after')->findAll();
        $result = [];
        
        foreach ($settings as $setting) {
            $key = str_replace($group . '.', '', $setting['key']);
            $result[$key] = $this->parseValue($setting['value'], $setting['type']);
        }
        
        return $result;
    }

    /**
     * Définit plusieurs paramètres d'un groupe
     */
    public function setSettingsByGroup($group, $settings)
    {
        foreach ($settings as $key => $value) {
            $fullKey = $group . '.' . $key;
            $this->setValue($fullKey, $value);
        }
    }

    /**
     * Parse une valeur selon son type
     */
    private function parseValue($value, $type)
    {
        switch ($type) {
            case 'integer':
                return (int) $value;
            case 'float':
                return (float) $value;
            case 'boolean':
                return (bool) $value;
            case 'json':
                return json_decode($value, true);
            case 'text':
            case 'string':
            default:
                return $value;
        }
    }

    /**
     * Formate une valeur pour le stockage
     */
    private function formatValue($value, $type)
    {
        switch ($type) {
            case 'json':
                return json_encode($value);
            case 'boolean':
                return $value ? '1' : '0';
            default:
                return (string) $value;
        }
    }

    /**
     * Récupère les paramètres de configuration SMTP
     */
    public function getSmtpSettings()
    {
        return $this->getSettingsByGroup('smtp');
    }

    /**
     * Récupère les paramètres de configuration SMS
     */
    public function getSmsSettings()
    {
        return $this->getSettingsByGroup('sms');
    }

    /**
     * Récupère les paramètres de configuration WhatsApp
     */
    public function getWhatsAppSettings()
    {
        return $this->getSettingsByGroup('whatsapp');
    }

    /**
     * Récupère les paramètres de configuration de l'application
     */
    public function getAppSettings()
    {
        return $this->getSettingsByGroup('app');
    }

    /**
     * Récupère les paramètres de configuration de la licence
     */
    public function getLicenseSettings()
    {
        return $this->getSettingsByGroup('license');
    }

    /**
     * Initialise les paramètres par défaut
     */
    public function initializeDefaultSettings()
    {
        $defaultSettings = [
            // Paramètres de l'application
            'app.name' => 'KISSAI SCHOOL',
            'app.version' => '1.0.0',
            'app.debug' => false,
            'app.timezone' => 'Africa/Douala',
            'app.language' => 'fr',
            
            // Paramètres SMTP
            'smtp.host' => 'localhost',
            'smtp.port' => 587,
            'smtp.username' => '',
            'smtp.password' => '',
            'smtp.encryption' => 'tls',
            'smtp.from_email' => 'noreply@kissai-school.com',
            'smtp.from_name' => 'KISSAI SCHOOL',
            
            // Paramètres SMS
            'sms.provider' => 'default',
            'sms.api_key' => '',
            'sms.api_secret' => '',
            'sms.sender_id' => 'KISSAI',
            
            // Paramètres WhatsApp
            'whatsapp.provider' => 'default',
            'whatsapp.api_key' => '',
            'whatsapp.api_secret' => '',
            'whatsapp.phone_number' => '',
            
            // Paramètres de licence
            'license.secret_seed' => 'KISSAI_SECRET_KEY_2025',
            'license.trial_duration' => 90, // jours
            'license.max_users' => 1000,
            'license.features' => json_encode(['economat', 'scolarite', 'etudes', 'examens', 'statistiques', 'bibliotheque', 'messagerie', 'securite'])
        ];

        foreach ($defaultSettings as $key => $value) {
            $type = is_bool($value) ? 'boolean' : (is_array($value) ? 'json' : 'string');
            $this->setValue($key, $value, $type, 'Paramètre par défaut', true);
        }
    }
}




