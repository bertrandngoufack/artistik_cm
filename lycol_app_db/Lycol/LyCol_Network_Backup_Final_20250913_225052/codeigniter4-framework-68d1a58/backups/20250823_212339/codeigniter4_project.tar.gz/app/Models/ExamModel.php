<?php

namespace App\Models;

use CodeIgniter\Model;

class ExamModel extends Model
{
    protected $table = 'exams';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;

    protected $allowedFields = [
        'name', 'type', 'class_id', 'subject_id', 'exam_date', 'total_marks', 'status'
    ];

    protected $useTimestamps = true;
    protected $dateFormat = 'datetime';
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    protected $validationRules = [
        'name' => 'required|min_length[2]|max_length[100]',
        'type' => 'required|in_list[CONTROL,EXAM,COMPOSITION]',
        'class_id' => 'required|integer',
        'subject_id' => 'required|integer',
        'exam_date' => 'required|valid_date',
        'total_marks' => 'required|numeric|greater_than[0]'
    ];

    protected $skipValidation = false;
    protected $cleanValidationRules = true;

    public function getExamsByClass($classId)
    {
        return $this->select('exams.*, subjects.name as subject_name')
                   ->join('subjects', 'subjects.id = exams.subject_id')
                   ->where('exams.class_id', $classId)
                   ->orderBy('exams.exam_date', 'DESC')
                   ->findAll();
    }

    public function getCompletedExams()
    {
        return $this->where('status', 'COMPLETED')
                   ->orderBy('exam_date', 'DESC')
                   ->findAll();
    }
}




