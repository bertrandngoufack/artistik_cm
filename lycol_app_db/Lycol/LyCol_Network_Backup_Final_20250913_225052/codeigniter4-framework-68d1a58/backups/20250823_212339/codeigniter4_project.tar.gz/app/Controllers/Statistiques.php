<?php

namespace App\Controllers;

use App\Models\StudentModel;
use App\Models\GradeModel;
use App\Models\PaymentModel;
use App\Models\AbsenceModel;

class Statistiques extends BaseController
{
    protected $studentModel;
    protected $gradeModel;
    protected $paymentModel;
    protected $absenceModel;

    public function __construct()
    {
        $this->studentModel = new StudentModel();
        $this->gradeModel = new GradeModel();
        $this->paymentModel = new PaymentModel();
        $this->absenceModel = new AbsenceModel();
    }

    public function index()
    {
        $data = [
            'title' => 'Module Statistiques',
            'stats' => $this->getGlobalStats()
        ];

        return view('admin/statistiques/dashboard', $data);
    }

    public function students()
    {
        $data = [
            'title' => 'Statistiques des Élèves',
            'stats' => $this->getStudentStatistics()
        ];

        return view('admin/statistiques/students', $data);
    }

    public function grades()
    {
        $data = [
            'title' => 'Statistiques des Notes',
            'stats' => $this->getGradeStatistics()
        ];

        return view('admin/statistiques/grades', $data);
    }

    public function payments()
    {
        $data = [
            'title' => 'Statistiques des Paiements',
            'stats' => $this->getPaymentStatistics()
        ];

        return view('admin/statistiques/payments', $data);
    }

    public function absences()
    {
        $data = [
            'title' => 'Statistiques des Absences',
            'stats' => $this->getAbsenceStatistics()
        ];

        return view('admin/statistiques/absences', $data);
    }

    public function reports()
    {
        $data = [
            'title' => 'Rapports Statistiques',
            'reports' => $this->getAvailableReports()
        ];

        return view('admin/statistiques/reports', $data);
    }

    public function export($type = 'students')
    {
        switch ($type) {
            case 'students':
                $data = $this->studentModel->getAllStudentsWithClasses();
                $filename = 'eleves_' . date('Y-m-d') . '.csv';
                break;
            case 'grades':
                $data = $this->gradeModel->getAllGrades();
                $filename = 'notes_' . date('Y-m-d') . '.csv';
                break;
            case 'payments':
                $data = $this->paymentModel->getAllPayments();
                $filename = 'paiements_' . date('Y-m-d') . '.csv';
                break;
            case 'absences':
                $data = $this->absenceModel->getAllAbsences();
                $filename = 'absences_' . date('Y-m-d') . '.csv';
                break;
            default:
                return redirect()->back()->with('error', 'Type d\'export non valide');
        }

        return $this->response->download($filename, $this->generateCSV($data));
    }

    private function getGlobalStats()
    {
        return [
            'totalStudents' => $this->studentModel->getStudentStats()['total'],
            'totalGrades' => $this->gradeModel->getGradeStats()['total'],
            'totalPayments' => $this->paymentModel->getTotalRevenue(),
            'totalAbsences' => $this->absenceModel->getAbsenceStats()['total']
        ];
    }

    private function getStudentStatistics()
    {
        return [
            'byGender' => $this->studentModel->getStudentStats()['by_gender'],
            'byClass' => $this->studentModel->getStudentStats()['by_class'],
            'enrollmentTrend' => $this->studentModel->getEnrollmentTrend()
        ];
    }

    private function getGradeStatistics()
    {
        return [
            'averageScores' => $this->gradeModel->getAverageScores(),
            'passRates' => $this->gradeModel->getPassRates(),
            'topStudents' => $this->gradeModel->getTopStudents()
        ];
    }

    private function getPaymentStatistics()
    {
        return [
            'totalRevenue' => $this->paymentModel->getTotalRevenue(),
            'monthlyRevenue' => $this->paymentModel->getMonthlyRevenue(),
            'paymentMethods' => $this->paymentModel->getPaymentMethodDistribution()
        ];
    }

    private function getAbsenceStatistics()
    {
        return [
            'totalAbsences' => $this->absenceModel->getAbsenceStats()['total'],
            'byDuration' => $this->absenceModel->getAbsenceStats()['by_duration'],
            'monthlyTrend' => $this->absenceModel->getMonthlyTrend()
        ];
    }

    private function getAvailableReports()
    {
        return [
            'student_report' => 'Rapport des Élèves',
            'grade_report' => 'Rapport des Notes',
            'payment_report' => 'Rapport des Paiements',
            'absence_report' => 'Rapport des Absences'
        ];
    }

    private function generateCSV($data)
    {
        if (empty($data)) {
            return '';
        }

        $output = fopen('php://temp', 'r+');
        
        // Headers
        fputcsv($output, array_keys($data[0]));
        
        // Data
        foreach ($data as $row) {
            fputcsv($output, $row);
        }
        
        rewind($output);
        $csv = stream_get_contents($output);
        fclose($output);
        
        return $csv;
    }
}




