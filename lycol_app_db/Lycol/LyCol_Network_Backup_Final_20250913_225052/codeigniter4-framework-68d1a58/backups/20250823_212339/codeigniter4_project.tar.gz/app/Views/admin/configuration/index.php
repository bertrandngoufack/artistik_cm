<?= $this->extend('admin/layout') ?>

<?= $this->section('content') ?>

<div class="container">
    <div class="columns">
        <div class="column">
            <h1 class="title">
                <i class="fas fa-cogs"></i>
                Configuration du Système
            </h1>
            <p class="subtitle">Gérez les paramètres et fournisseurs de KISSAI SCHOOL</p>
        </div>
    </div>

    <div class="columns is-multiline">
        <!-- Paramètres Généraux -->
        <div class="column is-4">
            <div class="card">
                <div class="card-content">
                    <div class="media">
                        <div class="media-left">
                            <figure class="image is-48x48">
                                <i class="fas fa-school" style="font-size: 2rem; color: #3273dc;"></i>
                            </figure>
                        </div>
                        <div class="media-content">
                            <p class="title is-4">Paramètres Généraux</p>
                            <p class="subtitle is-6">Informations de l'établissement</p>
                        </div>
                    </div>
                    <div class="content">
                        <p>Configurez les informations de base de l'école : nom, adresse, contact, année académique, etc.</p>
                        <a href="<?= base_url('admin/configuration/general') ?>" class="button is-primary">
                            <i class="fas fa-edit"></i>
                            Configurer
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Configuration Email -->
        <div class="column is-4">
            <div class="card">
                <div class="card-content">
                    <div class="media">
                        <div class="media-left">
                            <figure class="image is-48x48">
                                <i class="fas fa-envelope" style="font-size: 2rem; color: #00d1b2;"></i>
                            </figure>
                        </div>
                        <div class="media-content">
                            <p class="title is-4">Configuration Email</p>
                            <p class="subtitle is-6">Fournisseurs SMTP</p>
                        </div>
                    </div>
                    <div class="content">
                        <p>Configurez les fournisseurs email pour l'envoi automatique de rappels et notifications.</p>
                        <a href="<?= base_url('admin/configuration/email') ?>" class="button is-info">
                            <i class="fas fa-edit"></i>
                            Configurer
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Configuration SMS -->
        <div class="column is-4">
            <div class="card">
                <div class="card-content">
                    <div class="media">
                        <div class="media-left">
                            <figure class="image is-48x48">
                                <i class="fas fa-sms" style="font-size: 2rem; color: #ff3860;"></i>
                            </figure>
                        </div>
                        <div class="media-content">
                            <p class="title is-4">Configuration SMS</p>
                            <p class="subtitle is-6">Fournisseurs SMS</p>
                        </div>
                    </div>
                    <div class="content">
                        <p>Configurez les fournisseurs SMS pour l'envoi de rappels de paiement et notifications.</p>
                        <a href="<?= base_url('admin/configuration/sms') ?>" class="button is-danger">
                            <i class="fas fa-edit"></i>
                            Configurer
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Configuration WhatsApp -->
        <div class="column is-4">
            <div class="card">
                <div class="card-content">
                    <div class="media">
                        <div class="media-left">
                            <figure class="image is-48x48">
                                <i class="fab fa-whatsapp" style="font-size: 2rem; color: #25d366;"></i>
                            </figure>
                        </div>
                        <div class="media-content">
                            <p class="title is-4">Configuration WhatsApp</p>
                            <p class="subtitle is-6">WhatsApp Business API</p>
                        </div>
                    </div>
                    <div class="content">
                        <p>Configurez WhatsApp Business API pour l'envoi de messages de rappel automatiques.</p>
                        <a href="<?= base_url('admin/configuration/whatsapp') ?>" class="button is-success">
                            <i class="fas fa-edit"></i>
                            Configurer
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sauvegarde et Restauration -->
        <div class="column is-4">
            <div class="card">
                <div class="card-content">
                    <div class="media">
                        <div class="media-left">
                            <figure class="image is-48x48">
                                <i class="fas fa-database" style="font-size: 2rem; color: #7957d5;"></i>
                            </figure>
                        </div>
                        <div class="media-content">
                            <p class="title is-4">Sauvegarde</p>
                            <p class="subtitle is-6">Base de données</p>
                        </div>
                    </div>
                    <div class="content">
                        <p>Sauvegardez et restaurez la base de données du système.</p>
                        <button class="button is-warning" onclick="backupDatabase()">
                            <i class="fas fa-download"></i>
                            Sauvegarder
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Logs Système -->
        <div class="column is-4">
            <div class="card">
                <div class="card-content">
                    <div class="media">
                        <div class="media-left">
                            <figure class="image is-48x48">
                                <i class="fas fa-file-alt" style="font-size: 2rem; color: #363636;"></i>
                            </figure>
                        </div>
                        <div class="media-content">
                            <p class="title is-4">Logs Système</p>
                            <p class="subtitle is-6">Journaux d'activité</p>
                        </div>
                    </div>
                    <div class="content">
                        <p>Consultez les journaux d'activité et les erreurs du système.</p>
                        <button class="button is-dark" onclick="viewLogs()">
                            <i class="fas fa-eye"></i>
                            Consulter
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Statut des Services -->
    <div class="columns">
        <div class="column">
            <div class="card">
                <div class="card-header">
                    <p class="card-header-title">
                        <i class="fas fa-chart-line"></i>
                        Statut des Services
                    </p>
                </div>
                <div class="card-content">
                    <div class="columns">
                        <div class="column is-3">
                            <div class="notification is-success">
                                <p><strong>Base de données</strong></p>
                                <p>✅ Connectée</p>
                            </div>
                        </div>
                        <div class="column is-3">
                            <div class="notification is-warning">
                                <p><strong>Email</strong></p>
                                <p>⚠️ Non configuré</p>
                            </div>
                        </div>
                        <div class="column is-3">
                            <div class="notification is-warning">
                                <p><strong>SMS</strong></p>
                                <p>⚠️ Non configuré</p>
                            </div>
                        </div>
                        <div class="column is-3">
                            <div class="notification is-warning">
                                <p><strong>WhatsApp</strong></p>
                                <p>⚠️ Non configuré</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function backupDatabase() {
    if (confirm('Voulez-vous créer une sauvegarde de la base de données ?')) {
        // Implémentation de la sauvegarde
        alert('Fonctionnalité de sauvegarde à implémenter');
    }
}

function viewLogs() {
    // Implémentation de la consultation des logs
    alert('Fonctionnalité de consultation des logs à implémenter');
}
</script>

<?= $this->endSection() ?>


