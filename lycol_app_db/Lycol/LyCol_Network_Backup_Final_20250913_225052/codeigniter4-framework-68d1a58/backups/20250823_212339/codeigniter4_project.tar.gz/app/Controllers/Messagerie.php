<?php

namespace App\Controllers;

use App\Models\MessageModel;
use App\Models\TemplateModel;

class Messagerie extends BaseController
{
    protected $messageModel;
    protected $templateModel;

    public function __construct()
    {
        $this->messageModel = new MessageModel();
        $this->templateModel = new TemplateModel();
    }

    public function index()
    {
        $data = [
            'title' => 'Module Messagerie',
            'stats' => $this->getMessagingStats(),
            'recentMessages' => $this->messageModel->getRecentMessages(10)
        ];

        return view('admin/messagerie/dashboard', $data);
    }

    public function messages()
    {
        $data = [
            'title' => 'Gestion des Messages',
            'messages' => $this->messageModel->getMessagesPaginated(),
            'pager' => $this->messageModel->getMessagesPager()
        ];

        return view('admin/messagerie/messages', $data);
    }

    public function createMessage()
    {
        $data = [
            'title' => 'Nouveau Message',
            'templates' => $this->templateModel->getActiveTemplates()
        ];

        return view('admin/messagerie/create_message', $data);
    }

    public function storeMessage()
    {
        $rules = [
            'subject' => 'required|min_length[2]|max_length[200]',
            'content' => 'required|min_length[10]',
            'recipients' => 'required',
            'message_type' => 'required|in_list[EMAIL,SMS,WHATSAPP]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $messageData = [
            'subject' => $this->request->getPost('subject'),
            'content' => $this->request->getPost('content'),
            'recipients' => $this->request->getPost('recipients'),
            'message_type' => $this->request->getPost('message_type'),
            'status' => 'PENDING',
            'sent_by' => session()->get('user_id')
        ];

        if ($this->messageModel->insert($messageData)) {
            return redirect()->to('admin/messagerie/messages')->with('success', 'Message créé avec succès');
        } else {
            return redirect()->back()->withInput()->with('error', 'Erreur lors de la création');
        }
    }

    public function viewMessage($id)
    {
        $message = $this->messageModel->find($id);
        
        if (!$message) {
            return redirect()->to('admin/messagerie/messages')->with('error', 'Message non trouvé');
        }

        $data = [
            'title' => 'Détails du Message',
            'message' => $message
        ];

        return view('admin/messagerie/view_message', $data);
    }

    public function deleteMessage($id)
    {
        if ($this->messageModel->delete($id)) {
            return redirect()->to('admin/messagerie/messages')->with('success', 'Message supprimé avec succès');
        } else {
            return redirect()->to('admin/messagerie/messages')->with('error', 'Erreur lors de la suppression');
        }
    }

    public function templates()
    {
        $data = [
            'title' => 'Modèles de Messages',
            'templates' => $this->templateModel->getTemplatesPaginated(),
            'pager' => $this->templateModel->getTemplatesPager()
        ];

        return view('admin/messagerie/templates', $data);
    }

    public function createTemplate()
    {
        $data = [
            'title' => 'Nouveau Modèle'
        ];

        return view('admin/messagerie/create_template', $data);
    }

    public function storeTemplate()
    {
        $rules = [
            'name' => 'required|min_length[2]|max_length[100]',
            'subject' => 'required|min_length[2]|max_length[200]',
            'content' => 'required|min_length[10]',
            'message_type' => 'required|in_list[EMAIL,SMS,WHATSAPP]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $templateData = [
            'name' => $this->request->getPost('name'),
            'subject' => $this->request->getPost('subject'),
            'content' => $this->request->getPost('content'),
            'message_type' => $this->request->getPost('message_type'),
            'is_active' => 1
        ];

        if ($this->templateModel->insert($templateData)) {
            return redirect()->to('admin/messagerie/templates')->with('success', 'Modèle créé avec succès');
        } else {
            return redirect()->back()->withInput()->with('error', 'Erreur lors de la création');
        }
    }

    public function subscribers()
    {
        $data = [
            'title' => 'Gestion des Abonnés',
            'subscribers' => $this->messageModel->getSubscribers()
        ];

        return view('admin/messagerie/subscribers', $data);
    }

    public function settings()
    {
        $data = [
            'title' => 'Configuration Messagerie'
        ];

        return view('admin/messagerie/settings', $data);
    }

    private function getMessagingStats()
    {
        return [
            'totalMessages' => $this->messageModel->countAllResults(),
            'sentMessages' => $this->messageModel->where('status', 'SENT')->countAllResults(),
            'pendingMessages' => $this->messageModel->where('status', 'PENDING')->countAllResults(),
            'totalTemplates' => $this->templateModel->countAllResults()
        ];
    }
}




