<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Models\RoleModel;

class Securite extends BaseController
{
    protected $userModel;
    protected $roleModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
        $this->roleModel = new RoleModel();
    }

    public function index()
    {
        $data = [
            'title' => 'Module Sécurité',
            'stats' => $this->getSecurityStats()
        ];

        return view('admin/securite/dashboard', $data);
    }

    public function users()
    {
        $data = [
            'title' => 'Gestion des Utilisateurs',
            'users' => $this->userModel->getUsersPaginated(),
            'pager' => $this->userModel->getUsersPager(),
            'roles' => $this->roleModel->getActiveRoles()
        ];

        return view('admin/securite/users', $data);
    }

    public function createUser()
    {
        $data = [
            'title' => 'Nouvel Utilisateur',
            'roles' => $this->roleModel->getActiveRoles()
        ];

        return view('admin/securite/create_user', $data);
    }

    public function storeUser()
    {
        $rules = [
            'username' => 'required|min_length[3]|max_length[50]|is_unique[users.username]',
            'email' => 'required|valid_email|is_unique[users.email]',
            'first_name' => 'required|min_length[2]|max_length[50]',
            'last_name' => 'required|min_length[2]|max_length[50]',
            'role_id' => 'required|integer',
            'password' => 'required|min_length[6]',
            'password_confirm' => 'required|matches[password]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $userData = [
            'username' => $this->request->getPost('username'),
            'email' => $this->request->getPost('email'),
            'first_name' => $this->request->getPost('first_name'),
            'last_name' => $this->request->getPost('last_name'),
            'role_id' => $this->request->getPost('role_id'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
            'is_active' => 1
        ];

        if ($this->userModel->insert($userData)) {
            return redirect()->to('admin/securite/users')->with('success', 'Utilisateur créé avec succès');
        } else {
            return redirect()->back()->withInput()->with('error', 'Erreur lors de la création');
        }
    }

    public function editUser($id)
    {
        $user = $this->userModel->getUserWithRole($id);
        
        if (!$user) {
            return redirect()->to('admin/securite/users')->with('error', 'Utilisateur non trouvé');
        }

        $data = [
            'title' => 'Modifier l\'Utilisateur',
            'user' => $user,
            'roles' => $this->roleModel->getActiveRoles()
        ];

        return view('admin/securite/edit_user', $data);
    }

    public function updateUser($id)
    {
        $rules = [
            'username' => 'required|min_length[3]|max_length[50]|is_unique[users.username,id,' . $id . ']',
            'email' => 'required|valid_email|is_unique[users.email,id,' . $id . ']',
            'first_name' => 'required|min_length[2]|max_length[50]',
            'last_name' => 'required|min_length[2]|max_length[50]',
            'role_id' => 'required|integer'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $userData = [
            'username' => $this->request->getPost('username'),
            'email' => $this->request->getPost('email'),
            'first_name' => $this->request->getPost('first_name'),
            'last_name' => $this->request->getPost('last_name'),
            'role_id' => $this->request->getPost('role_id')
        ];

        // Si un nouveau mot de passe est fourni
        if ($this->request->getPost('password')) {
            $userData['password'] = password_hash($this->request->getPost('password'), PASSWORD_DEFAULT);
        }

        if ($this->userModel->update($id, $userData)) {
            return redirect()->to('admin/securite/users')->with('success', 'Utilisateur mis à jour avec succès');
        } else {
            return redirect()->back()->withInput()->with('error', 'Erreur lors de la mise à jour');
        }
    }

    public function deleteUser($id)
    {
        if ($this->userModel->delete($id)) {
            return redirect()->to('admin/securite/users')->with('success', 'Utilisateur supprimé avec succès');
        } else {
            return redirect()->to('admin/securite/users')->with('error', 'Erreur lors de la suppression');
        }
    }

    public function roles()
    {
        $data = [
            'title' => 'Gestion des Rôles',
            'roles' => $this->roleModel->getRolesPaginated(),
            'pager' => $this->roleModel->getRolesPager()
        ];

        return view('admin/securite/roles', $data);
    }

    public function createRole()
    {
        $data = [
            'title' => 'Nouveau Rôle'
        ];

        return view('admin/securite/create_role', $data);
    }

    public function storeRole()
    {
        $rules = [
            'name' => 'required|min_length[2]|max_length[50]|is_unique[roles.name]',
            'description' => 'required|max_length[200]',
            'permissions' => 'required'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $roleData = [
            'name' => $this->request->getPost('name'),
            'description' => $this->request->getPost('description'),
            'permissions' => json_encode($this->request->getPost('permissions')),
            'is_active' => 1
        ];

        if ($this->roleModel->insert($roleData)) {
            return redirect()->to('admin/securite/roles')->with('success', 'Rôle créé avec succès');
        } else {
            return redirect()->back()->withInput()->with('error', 'Erreur lors de la création');
        }
    }

    public function editRole($id)
    {
        $role = $this->roleModel->find($id);
        
        if (!$role) {
            return redirect()->to('admin/securite/roles')->with('error', 'Rôle non trouvé');
        }

        $data = [
            'title' => 'Modifier le Rôle',
            'role' => $role
        ];

        return view('admin/securite/edit_role', $data);
    }

    public function updateRole($id)
    {
        $rules = [
            'name' => 'required|min_length[2]|max_length[50]|is_unique[roles.name,id,' . $id . ']',
            'description' => 'required|max_length[200]',
            'permissions' => 'required'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $roleData = [
            'name' => $this->request->getPost('name'),
            'description' => $this->request->getPost('description'),
            'permissions' => json_encode($this->request->getPost('permissions'))
        ];

        if ($this->roleModel->update($id, $roleData)) {
            return redirect()->to('admin/securite/roles')->with('success', 'Rôle mis à jour avec succès');
        } else {
            return redirect()->back()->withInput()->with('error', 'Erreur lors de la mise à jour');
        }
    }

    public function deleteRole($id)
    {
        if ($this->roleModel->delete($id)) {
            return redirect()->to('admin/securite/roles')->with('success', 'Rôle supprimé avec succès');
        } else {
            return redirect()->to('admin/securite/roles')->with('error', 'Erreur lors de la suppression');
        }
    }

    public function logs()
    {
        $data = [
            'title' => 'Journaux d\'Audit',
            'logs' => $this->getAuditLogs()
        ];

        return view('admin/securite/logs', $data);
    }

    private function getSecurityStats()
    {
        return [
            'totalUsers' => $this->userModel->countAllResults(),
            'activeUsers' => $this->userModel->where('is_active', 1)->countAllResults(),
            'totalRoles' => $this->roleModel->countAllResults(),
            'recentLogins' => $this->getRecentLogins()
        ];
    }

    private function getAuditLogs()
    {
        // Simulation des journaux d'audit
        return [
            ['action' => 'Connexion', 'user' => 'admin', 'timestamp' => date('Y-m-d H:i:s')],
            ['action' => 'Modification utilisateur', 'user' => 'admin', 'timestamp' => date('Y-m-d H:i:s', strtotime('-1 hour'))],
            ['action' => 'Création rôle', 'user' => 'admin', 'timestamp' => date('Y-m-d H:i:s', strtotime('-2 hours'))]
        ];
    }

    private function getRecentLogins()
    {
        // Simulation des connexions récentes
        return [
            ['user' => 'admin', 'timestamp' => date('Y-m-d H:i:s')],
            ['user' => 'directeur', 'timestamp' => date('Y-m-d H:i:s', strtotime('-30 minutes'))],
            ['user' => 'secretaire', 'timestamp' => date('Y-m-d H:i:s', strtotime('-1 hour'))]
        ];
    }
}




