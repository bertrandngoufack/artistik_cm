<?php

namespace App\Models;

use CodeIgniter\Model;

class AbsenceModel extends Model
{
    protected $table = 'absences';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;

    protected $allowedFields = [
        'student_id', 'absence_date', 'reason', 'duration', 'recorded_by'
    ];

    protected $useTimestamps = true;
    protected $dateFormat = 'datetime';
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    protected $validationRules = [
        'student_id' => 'required|integer',
        'absence_date' => 'required|valid_date',
        'reason' => 'required|max_length[500]',
        'duration' => 'required|in_list[HALF_DAY,FULL_DAY,MULTIPLE_DAYS]'
    ];

    protected $skipValidation = false;
    protected $cleanValidationRules = true;

    public function getAbsencesPaginated($page = 1, $perPage = 20)
    {
        return $this->select('absences.*, students.first_name, students.last_name, students.matricule, classes.name as class_name')
                   ->join('students', 'students.id = absences.student_id')
                   ->join('classes', 'classes.id = students.current_class_id')
                   ->orderBy('absences.absence_date', 'DESC')
                   ->paginate($perPage, 'default', $page);
    }

    public function getAbsencesPager()
    {
        return $this->pager;
    }

    public function getRecentAbsences($limit = 10)
    {
        return $this->select('absences.*, students.first_name, students.last_name, students.matricule')
                   ->join('students', 'students.id = absences.student_id')
                   ->orderBy('absences.absence_date', 'DESC')
                   ->limit($limit)
                   ->findAll();
    }

    public function getAbsencesByStudent($studentId)
    {
        return $this->where('student_id', $studentId)
                   ->orderBy('absence_date', 'DESC')
                   ->findAll();
    }

    public function getAbsenceStats()
    {
        return [
            'total' => $this->countAllResults(),
            'this_month' => $this->where('MONTH(absence_date)', date('m'))
                                ->where('YEAR(absence_date)', date('Y'))
                                ->countAllResults(),
            'by_duration' => $this->select('duration, COUNT(*) as count')
                                ->groupBy('duration')
                                ->findAll()
        ];
    }

    public function createAbsence($data)
    {
        return $this->insert($data);
    }
}




