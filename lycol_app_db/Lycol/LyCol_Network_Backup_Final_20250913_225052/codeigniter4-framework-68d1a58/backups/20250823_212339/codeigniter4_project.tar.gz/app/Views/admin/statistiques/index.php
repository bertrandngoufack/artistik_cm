<?= $this->extend('admin/layout') ?>

<?= $this->section('content') ?>
<div class="level">
    <div class="level-left">
        <div class="level-item">
            <h1 class="title">Module Statistiques</h1>
        </div>
    </div>
    <div class="level-right">
        <div class="level-item">
            <a href="<?= base_url('admin/statistiques/export') ?>" class="button is-primary">
                <span class="icon"><i class="fas fa-download"></i></span>
                <span>Exporter</span>
            </a>
        </div>
    </div>
</div>

<div class="columns is-multiline">
    <!-- Statistiques générales -->
    <div class="column is-3">
        <div class="card">
            <div class="card-content">
                <div class="content">
                    <p class="heading">Total Élèves</p>
                    <p class="title"><?= number_format($total_students ?? 0) ?></p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="column is-3">
        <div class="card">
            <div class="card-content">
                <div class="content">
                    <p class="heading">Total Classes</p>
                    <p class="title"><?= number_format($total_classes ?? 0) ?></p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="column is-3">
        <div class="card">
            <div class="card-content">
                <div class="content">
                    <p class="heading">Total Enseignants</p>
                    <p class="title"><?= number_format($total_teachers ?? 0) ?></p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="column is-3">
        <div class="card">
            <div class="card-content">
                <div class="content">
                    <p class="heading">Taux de Réussite</p>
                    <p class="title"><?= number_format($success_rate ?? 0, 1) ?>%</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Graphiques et rapports -->
<div class="columns">
    <div class="column is-6">
        <div class="card">
            <header class="card-header">
                <p class="card-header-title">
                    <span class="icon"><i class="fas fa-chart-pie"></i></span>
                    Répartition par Genre
                </p>
            </header>
            <div class="card-content">
                <div class="content">
                    <p class="has-text-centered has-text-grey">Graphique en cours de développement</p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="column is-6">
        <div class="card">
            <header class="card-header">
                <p class="card-header-title">
                    <span class="icon"><i class="fas fa-chart-bar"></i></span>
                    Performance par Classe
                </p>
            </header>
            <div class="card-content">
                <div class="content">
                    <p class="has-text-centered has-text-grey">Graphique en cours de développement</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Actions rapides -->
<div class="columns">
    <div class="column">
        <div class="card">
            <header class="card-header">
                <p class="card-header-title">
                    <span class="icon"><i class="fas fa-tasks"></i></span>
                    Rapports Disponibles
                </p>
            </header>
            <div class="card-content">
                <div class="buttons">
                    <a href="<?= base_url('admin/statistiques/students') ?>" class="button is-primary">
                        <span class="icon"><i class="fas fa-users"></i></span>
                        <span>Statistiques Élèves</span>
                    </a>
                    <a href="<?= base_url('admin/statistiques/academic') ?>" class="button is-info">
                        <span class="icon"><i class="fas fa-graduation-cap"></i></span>
                        <span>Performance Académique</span>
                    </a>
                    <a href="<?= base_url('admin/statistiques/financial') ?>" class="button is-success">
                        <span class="icon"><i class="fas fa-money-bill"></i></span>
                        <span>Statistiques Financières</span>
                    </a>
                    <a href="<?= base_url('admin/statistiques/attendance') ?>" class="button is-warning">
                        <span class="icon"><i class="fas fa-calendar-check"></i></span>
                        <span>Présence et Absences</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>




