<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Route par défaut
$routes->get('/', 'Home::index');

// Routes d'authentification
$routes->group('auth', ['namespace' => 'App\Controllers'], function($routes) {
    $routes->get('login', 'Auth::login');
    $routes->post('authenticate', 'Auth::authenticate');
    $routes->get('logout', 'Auth::logout');
    $routes->get('parents', 'Auth::parents');
    $routes->post('authenticate-parent', 'Auth::authenticateParent');
    $routes->get('mobile', 'Auth::mobile');
    $routes->post('authenticate-mobile', 'Auth::authenticateMobile');
    $routes->get('change-password', 'Auth::changePassword');
    $routes->post('update-password', 'Auth::updatePassword');
});

// Routes d'administration
$routes->group('admin', ['namespace' => 'App\Controllers', 'filter' => 'auth'], function($routes) {
    // Dashboard
    $routes->get('dashboard', 'Admin::dashboard');
    
    // Module Économat
    $routes->group('economat', function($routes) {
        $routes->get('/', 'Economat::index');
        $routes->get('payments', 'Economat::payments');
        $routes->get('payments/create', 'Economat::createPayment');
        $routes->post('payments/store', 'Economat::storePayment');
        $routes->get('payments/(:num)', 'Economat::viewPayment/$1');
        $routes->get('payments/(:num)/edit', 'Economat::editPayment/$1');
        $routes->post('payments/(:num)/update', 'Economat::updatePayment/$1');
        $routes->get('payments/(:num)/delete', 'Economat::deletePayment/$1');
        $routes->get('payments/(:num)/print', 'Economat::printReceipt/$1');
        $routes->get('payments/(:num)/pdf', 'Economat::exportReceiptPDF/$1');
        $routes->get('payments/(:num)/reminder', 'Economat::sendReminder/$1');
        $routes->get('payments/send-reminders', 'Economat::sendReminder');
        $routes->get('reminders', 'Economat::reminders');
        $routes->get('fees', 'Economat::fees');
        $routes->get('reports', 'Economat::reports');
    });
    
    // Module Scolarité
    $routes->group('scolarite', function($routes) {
        $routes->get('/', 'Scolarite::index');
        $routes->get('students', 'Scolarite::students');
        $routes->get('students/create', 'Scolarite::createStudent');
        $routes->post('students/store', 'Scolarite::storeStudent');
        $routes->get('students/(:num)/edit', 'Scolarite::editStudent/$1');
        $routes->post('students/(:num)/update', 'Scolarite::updateStudent/$1');
        $routes->get('students/(:num)/delete', 'Scolarite::deleteStudent/$1');
        $routes->get('students/(:num)/view', 'Scolarite::viewStudent/$1');
        $routes->get('absences', 'Scolarite::absences');
        $routes->get('absences/create', 'Scolarite::createAbsence');
        $routes->post('absences/store', 'Scolarite::storeAbsence');
        $routes->get('absences/(:num)/edit', 'Scolarite::editAbsence/$1');
        $routes->post('absences/(:num)/update', 'Scolarite::updateAbsence/$1');
        $routes->get('absences/(:num)/delete', 'Scolarite::deleteAbsence/$1');
        $routes->get('absences/(:num)/view', 'Scolarite::viewAbsence/$1');
        $routes->get('discipline', 'Scolarite::discipline');
        $routes->get('discipline/create', 'Scolarite::createIncident');
        $routes->post('discipline/store', 'Scolarite::storeIncident');
        $routes->get('discipline/(:num)/edit', 'Scolarite::editIncident/$1');
        $routes->post('discipline/(:num)/update', 'Scolarite::updateIncident/$1');
        $routes->get('discipline/(:num)/delete', 'Scolarite::deleteIncident/$1');
        $routes->get('discipline/(:num)/view', 'Scolarite::viewIncident/$1');
        $routes->get('discipline/(:num)/notify', 'Scolarite::sendDisciplineNotification/$1');
        $routes->get('discipline/notifications', 'Scolarite::disciplineNotifications');
        $routes->get('discipline/notifications/send-all', 'Scolarite::sendDisciplineNotification');
        $routes->get('reports', 'Scolarite::reports');
    });
    
    // Module Études
    $routes->group('etudes', function($routes) {
        $routes->get('/', 'Etudes::index');
        
        // Gestion des cycles
        $routes->get('cycles', 'Etudes::cycles');
        $routes->get('cycles/create', 'Etudes::createCycle');
        $routes->post('cycles/store', 'Etudes::storeCycle');
        $routes->get('cycles/(:num)/edit', 'Etudes::editCycle/$1');
        $routes->post('cycles/(:num)/update', 'Etudes::updateCycle/$1');
        $routes->get('cycles/(:num)/delete', 'Etudes::deleteCycle/$1');
        
        // Gestion des classes
        $routes->get('classes', 'Etudes::classes');
        $routes->get('classes/create', 'Etudes::createClass');
        $routes->post('classes/store', 'Etudes::storeClass');
        $routes->get('classes/(:num)/edit', 'Etudes::editClass/$1');
        $routes->post('classes/(:num)/update', 'Etudes::updateClass/$1');
        $routes->get('classes/(:num)/delete', 'Etudes::deleteClass/$1');
        $routes->get('classes/(:num)/view', 'Etudes::viewClass/$1');
        
        // Gestion des matières
        $routes->get('subjects', 'Etudes::subjects');
        $routes->get('subjects/create', 'Etudes::createSubject');
        $routes->post('subjects/store', 'Etudes::storeSubject');
        $routes->get('subjects/(:num)/edit', 'Etudes::editSubject/$1');
        $routes->post('subjects/(:num)/update', 'Etudes::updateSubject/$1');
        $routes->get('subjects/(:num)/delete', 'Etudes::deleteSubject/$1');
        
        // Gestion des emplois du temps
        $routes->get('timetable', 'Etudes::timetable');
        $routes->get('timetable/create', 'Etudes::createTimetable');
        $routes->post('timetable/store', 'Etudes::storeTimetable');
        $routes->get('timetable/(:num)/edit', 'Etudes::editTimetable/$1');
        $routes->post('timetable/(:num)/update', 'Etudes::updateTimetable/$1');
        $routes->get('timetable/(:num)/delete', 'Etudes::deleteTimetable/$1');
        $routes->get('timetable/class/(:num)', 'Etudes::viewClassTimetable/$1');
        
        // Gestion des assignations
        $routes->get('assignments', 'Etudes::assignments');
        $routes->get('assignments/create', 'Etudes::createAssignment');
        $routes->post('assignments/store', 'Etudes::storeAssignment');
        $routes->get('assignments/(:num)/edit', 'Etudes::editAssignment/$1');
        $routes->post('assignments/(:num)/update', 'Etudes::updateAssignment/$1');
        $routes->get('assignments/(:num)/delete', 'Etudes::deleteAssignment/$1');
    });
    
    // Module Examens
    $routes->group('examens', function($routes) {
        $routes->get('/', 'Admin::examens');
        $routes->get('exams', 'Examens::exams');
        $routes->get('exams/create', 'Examens::createExam');
        $routes->post('exams/store', 'Examens::storeExam');
        $routes->get('exams/(:num)/edit', 'Examens::editExam/$1');
        $routes->post('exams/(:num)/update', 'Examens::updateExam/$1');
        $routes->get('exams/(:num)/delete', 'Examens::deleteExam/$1');
        $routes->get('grades', 'Examens::grades');
        $routes->get('grades/enter/(:num)', 'Examens::enterGrades/$1');
        $routes->post('grades/store', 'Examens::storeGrades');
        $routes->get('report-cards', 'Examens::reportCards');
        $routes->get('report-cards/generate', 'Examens::generateReportCards');
        $routes->get('statistics', 'Examens::statistics');
    });
    
    // Module Statistiques
    $routes->group('statistiques', function($routes) {
        $routes->get('/', 'Admin::statistiques');
        $routes->get('students', 'Statistiques::students');
        $routes->get('grades', 'Statistiques::grades');
        $routes->get('payments', 'Statistiques::payments');
        $routes->get('absences', 'Statistiques::absences');
        $routes->get('reports', 'Statistiques::reports');
        $routes->get('export/(:any)', 'Statistiques::export/$1');
    });
    
    // Module Bibliothèque
    $routes->group('bibliotheque', function($routes) {
        $routes->get('/', 'Admin::bibliotheque');
        $routes->get('books', 'Bibliotheque::books');
        $routes->get('books/create', 'Bibliotheque::createBook');
        $routes->post('books/store', 'Bibliotheque::storeBook');
        $routes->get('books/(:num)/edit', 'Bibliotheque::editBook/$1');
        $routes->post('books/(:num)/update', 'Bibliotheque::updateBook/$1');
        $routes->get('books/(:num)/delete', 'Bibliotheque::deleteBook/$1');
        $routes->get('loans', 'Bibliotheque::loans');
        $routes->get('loans/create', 'Bibliotheque::createLoan');
        $routes->post('loans/store', 'Bibliotheque::storeLoan');
        $routes->get('loans/(:num)/return', 'Bibliotheque::returnLoan/$1');
        $routes->get('members', 'Bibliotheque::members');
    });
    
    // Module Messagerie
    $routes->group('messagerie', function($routes) {
        $routes->get('/', 'Admin::messagerie');
        $routes->get('messages', 'Messagerie::messages');
        $routes->get('messages/create', 'Messagerie::createMessage');
        $routes->post('messages/store', 'Messagerie::storeMessage');
        $routes->get('messages/(:num)/view', 'Messagerie::viewMessage/$1');
        $routes->get('messages/(:num)/delete', 'Messagerie::deleteMessage/$1');
        $routes->get('templates', 'Messagerie::templates');
        $routes->get('templates/create', 'Messagerie::createTemplate');
        $routes->post('templates/store', 'Messagerie::storeTemplate');
        $routes->get('subscribers', 'Messagerie::subscribers');
        $routes->get('settings', 'Messagerie::settings');
    });
    
    // Module Enseignants
    $routes->group('enseignants', function($routes) {
        $routes->get('/', 'Enseignants::index');
        $routes->get('list', 'Enseignants::list');
        $routes->get('create', 'Enseignants::create');
        $routes->post('store', 'Enseignants::store');
        $routes->get('show/(:num)', 'Enseignants::show/$1');
        $routes->get('edit/(:num)', 'Enseignants::edit/$1');
        $routes->post('update/(:num)', 'Enseignants::update/$1');
        $routes->get('delete/(:num)', 'Enseignants::delete/$1');
        $routes->get('subjects/(:num)', 'Enseignants::subjects/$1');
        $routes->post('assign-subject', 'Enseignants::assignSubject');
        $routes->post('remove-subject', 'Enseignants::removeSubject');
        $routes->get('classes/(:num)', 'Enseignants::classes/$1');
        $routes->post('assign-class', 'Enseignants::assignClass');
        $routes->post('remove-class', 'Enseignants::removeClass');
        $routes->get('statistics', 'Enseignants::statistics');
        $routes->get('export/(:any)', 'Enseignants::export/$1');
    });
    
    // Module Sécurité
    $routes->group('securite', function($routes) {
        $routes->get('/', 'Admin::securite');
        $routes->get('users', 'Securite::users');
        $routes->get('users/create', 'Securite::createUser');
        $routes->post('users/store', 'Securite::storeUser');
        $routes->get('users/(:num)/edit', 'Securite::editUser/$1');
        $routes->post('users/(:num)/update', 'Securite::updateUser/$1');
        $routes->get('users/(:num)/delete', 'Securite::deleteUser/$1');
        $routes->get('roles', 'Securite::roles');
        $routes->get('roles/create', 'Securite::createRole');
        $routes->post('roles/store', 'Securite::storeRole');
        $routes->get('roles/(:num)/edit', 'Securite::editRole/$1');
        $routes->post('roles/(:num)/update', 'Securite::updateRole/$1');
        $routes->get('roles/(:num)/delete', 'Securite::deleteRole/$1');
        $routes->get('licenses', 'Admin::licenses');
        $routes->post('licenses/generate', 'Admin::generateLicense');
        $routes->get('logs', 'Securite::logs');
    });
    
    // Module Configuration
    $routes->group('configuration', function($routes) {
        $routes->get('/', 'Configuration::index');
        $routes->get('general', 'Configuration::general');
        $routes->post('save-general', 'Configuration::saveGeneral');
        $routes->get('email', 'Configuration::email');
        $routes->post('save-email', 'Configuration::saveEmail');
        $routes->post('test-email', 'Configuration::testEmail');
        $routes->get('sms', 'Configuration::sms');
        $routes->post('save-sms', 'Configuration::saveSMS');
        $routes->post('test-sms', 'Configuration::testSMS');
        $routes->get('whatsapp', 'Configuration::whatsapp');
        $routes->post('save-whatsapp', 'Configuration::saveWhatsApp');
        $routes->post('test-whatsapp', 'Configuration::testWhatsApp');
    });
    
    // Export
    $routes->get('export/(:any)', 'Admin::export/$1');
});

// Routes pour les parents
$routes->group('parents', ['namespace' => 'App\Controllers', 'filter' => 'parent'], function($routes) {
    $routes->get('dashboard', 'Parents::dashboard');
    $routes->get('grades', 'Parents::grades');
    $routes->get('absences', 'Parents::absences');
    $routes->get('payments', 'Parents::payments');
    $routes->get('discipline', 'Parents::discipline');
    $routes->get('profile', 'Parents::profile');
});

// Routes pour l'interface mobile
$routes->group('mobile', ['namespace' => 'App\Controllers', 'filter' => 'mobile'], function($routes) {
    $routes->get('grades', 'Mobile::grades');
    $routes->get('grades/enter/(:num)', 'Mobile::enterGrades/$1');
    $routes->post('grades/store', 'Mobile::storeGrades');
    $routes->get('absences', 'Mobile::absences');
    $routes->get('absences/create', 'Mobile::createAbsence');
    $routes->post('absences/store', 'Mobile::storeAbsence');
    $routes->get('profile', 'Mobile::profile');
});

// Routes API
$routes->group('api', ['namespace' => 'App\Controllers\Api'], function($routes) {
    $routes->get('students/(:any)/(:num)', 'Students::getByMatriculeAndBirthYear/$1/$2');
    $routes->get('grades/(:any)/(:num)', 'Grades::getByMatriculeAndBirthYear/$1/$2');
    $routes->get('absences/(:any)/(:num)', 'Absences::getByMatriculeAndBirthYear/$1/$2');
    $routes->get('discipline/(:any)/(:num)', 'Discipline::getByMatriculeAndBirthYear/$1/$2');
    $routes->get('export/(:any)', 'Export::exportData/$1');
});

// Routes de documentation API
$routes->get('api/docs', 'Api\Docs::index');
$routes->get('api/docs/(:any)', 'Api\Docs::show/$1');

// Routes pour les pages publiques
$routes->get('about', 'Pages::about');
$routes->get('contact', 'Pages::contact');
$routes->get('help', 'Pages::help');
$routes->get('privacy', 'Pages::privacy');
$routes->get('terms', 'Pages::terms');

// Routes pour les erreurs
$routes->set404Override('App\Controllers\Errors::show404');
$routes->get('error/403', 'Errors::show403');
$routes->get('error/500', 'Errors::show500');

// Routes pour les tests (uniquement en développement)
if (ENVIRONMENT === 'development') {
    $routes->get('test/license', 'Test::license');
    $routes->get('test/database', 'Test::database');
    $routes->get('test/email', 'Test::email');
}
