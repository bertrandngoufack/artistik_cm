<?php

namespace App\Controllers;

use CodeIgniter\Controller;

/**
 * Class Configuration
 * Gestion des paramètres système et fournisseurs
 */
class Configuration extends BaseController
{
    /**
     * An array of helpers to be loaded automatically upon
     * class instantiation. These helpers will be available
     * to all other controllers that extend BaseController.
     *
     * @var array
     */
    protected $helpers = ['form', 'url'];



    /**
     * Page d'accueil de la configuration
     */
    public function index()
    {
        $data = [
            'title' => 'Configuration - KISSAI SCHOOL',
            'active_menu' => 'configuration'
        ];

        return view('admin/configuration/index', $data);
    }

    /**
     * Paramètres généraux
     */
    public function general()
    {
        $data = [
            'title' => 'Paramètres Généraux - KISSAI SCHOOL',
            'active_menu' => 'configuration',
            'submenu' => 'general'
        ];

        return view('admin/configuration/general', $data);
    }

    /**
     * Configuration Email
     */
    public function email()
    {
        $data = [
            'title' => 'Configuration Email - KISSAI SCHOOL',
            'active_menu' => 'configuration',
            'submenu' => 'email',
            'providers' => $this->getEmailProviders()
        ];

        return view('admin/configuration/email', $data);
    }

    /**
     * Configuration SMS
     */
    public function sms()
    {
        $data = [
            'title' => 'Configuration SMS - KISSAI SCHOOL',
            'active_menu' => 'configuration',
            'submenu' => 'sms',
            'providers' => $this->getSMSProviders()
        ];

        return view('admin/configuration/sms', $data);
    }

    /**
     * Configuration WhatsApp
     */
    public function whatsapp()
    {
        $data = [
            'title' => 'Configuration WhatsApp - KISSAI SCHOOL',
            'active_menu' => 'configuration',
            'submenu' => 'whatsapp',
            'providers' => $this->getWhatsAppProviders()
        ];

        return view('admin/configuration/whatsapp', $data);
    }

    /**
     * Sauvegarder les paramètres généraux
     */
    public function saveGeneral()
    {
        $rules = [
            'school_name' => 'required|min_length[3]',
            'school_address' => 'required',
            'school_phone' => 'required',
            'school_email' => 'required|valid_email',
            'school_website' => 'permit_empty|valid_url',
            'academic_year' => 'required',
            'currency' => 'required',
            'timezone' => 'required'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('error', 'Veuillez corriger les erreurs.');
        }

        $data = [
            'school_name' => $this->request->getPost('school_name'),
            'school_address' => $this->request->getPost('school_address'),
            'school_phone' => $this->request->getPost('school_phone'),
            'school_email' => $this->request->getPost('school_email'),
            'school_website' => $this->request->getPost('school_website'),
            'academic_year' => $this->request->getPost('academic_year'),
            'currency' => $this->request->getPost('currency'),
            'timezone' => $this->request->getPost('timezone'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        // Sauvegarder en base de données
        $this->saveSettings('general', $data);

        return redirect()->to('/admin/configuration/general')->with('success', 'Paramètres généraux sauvegardés avec succès.');
    }

    /**
     * Sauvegarder la configuration Email
     */
    public function saveEmail()
    {
        $rules = [
            'provider' => 'required',
            'from_email' => 'required|valid_email',
            'from_name' => 'required'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('error', 'Veuillez corriger les erreurs.');
        }

        $provider = $this->request->getPost('provider');
        $data = [
            'provider' => $provider,
            'from_email' => $this->request->getPost('from_email'),
            'from_name' => $this->request->getPost('from_name'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        // Configuration spécifique au fournisseur
        switch ($provider) {
            case 'gmail':
                $data['smtp_host'] = 'smtp.gmail.com';
                $data['smtp_port'] = 587;
                $data['smtp_crypto'] = 'tls';
                $data['smtp_user'] = $this->request->getPost('smtp_user');
                $data['smtp_pass'] = $this->request->getPost('smtp_pass');
                break;
            case 'office365':
                $data['smtp_host'] = 'smtp.office365.com';
                $data['smtp_port'] = 587;
                $data['smtp_crypto'] = 'tls';
                $data['smtp_user'] = $this->request->getPost('smtp_user');
                $data['smtp_pass'] = $this->request->getPost('smtp_pass');
                break;
            case 'outlook':
                $data['smtp_host'] = 'smtp-mail.outlook.com';
                $data['smtp_port'] = 587;
                $data['smtp_crypto'] = 'tls';
                $data['smtp_user'] = $this->request->getPost('smtp_user');
                $data['smtp_pass'] = $this->request->getPost('smtp_pass');
                break;
            case 'custom':
                $data['smtp_host'] = $this->request->getPost('smtp_host');
                $data['smtp_port'] = $this->request->getPost('smtp_port');
                $data['smtp_crypto'] = $this->request->getPost('smtp_crypto');
                $data['smtp_user'] = $this->request->getPost('smtp_user');
                $data['smtp_pass'] = $this->request->getPost('smtp_pass');
                break;
        }

        // Sauvegarder en base de données
        $this->saveSettings('email', $data);

        return redirect()->to('/admin/configuration/email')->with('success', 'Configuration Email sauvegardée avec succès.');
    }

    /**
     * Sauvegarder la configuration SMS
     */
    public function saveSMS()
    {
        $rules = [
            'provider' => 'required',
            'sender_name' => 'required'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('error', 'Veuillez corriger les erreurs.');
        }

        $provider = $this->request->getPost('provider');
        $data = [
            'provider' => $provider,
            'sender_name' => $this->request->getPost('sender_name'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        // Configuration spécifique au fournisseur
        switch ($provider) {
            case 'textlocal':
                $data['api_key'] = $this->request->getPost('api_key');
                break;
            case 'twilio':
                $data['account_sid'] = $this->request->getPost('account_sid');
                $data['auth_token'] = $this->request->getPost('auth_token');
                $data['phone_number'] = $this->request->getPost('phone_number');
                break;
            case 'msg91':
                $data['api_key'] = $this->request->getPost('api_key');
                break;
        }

        // Sauvegarder en base de données
        $this->saveSettings('sms', $data);

        return redirect()->to('/admin/configuration/sms')->with('success', 'Configuration SMS sauvegardée avec succès.');
    }

    /**
     * Sauvegarder la configuration WhatsApp
     */
    public function saveWhatsApp()
    {
        $rules = [
            'provider' => 'required'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('error', 'Veuillez corriger les erreurs.');
        }

        $provider = $this->request->getPost('provider');
        $data = [
            'provider' => $provider,
            'updated_at' => date('Y-m-d H:i:s')
        ];

        // Configuration spécifique au fournisseur
        switch ($provider) {
            case 'twilio':
                $data['account_sid'] = $this->request->getPost('account_sid');
                $data['auth_token'] = $this->request->getPost('auth_token');
                $data['phone_number'] = $this->request->getPost('phone_number');
                break;
            case 'dialog360':
                $data['api_key'] = $this->request->getPost('api_key');
                $data['phone_number'] = $this->request->getPost('phone_number');
                break;
        }

        // Sauvegarder en base de données
        $this->saveSettings('whatsapp', $data);

        return redirect()->to('/admin/configuration/whatsapp')->with('success', 'Configuration WhatsApp sauvegardée avec succès.');
    }

    /**
     * Tester la configuration Email
     */
    public function testEmail()
    {
        $email = $this->request->getPost('test_email');
        
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return $this->response->setJSON(['success' => false, 'message' => 'Adresse email invalide']);
        }

        // Récupérer la configuration actuelle
        $config = $this->getSettings('email');
        
        if (!$config) {
            return $this->response->setJSON(['success' => false, 'message' => 'Configuration email non trouvée']);
        }

        // Envoyer un email de test
        $emailConfig = new \Config\Email();
        $emailConfig->fromEmail = $config['from_email'];
        $emailConfig->fromName = $config['from_name'];
        $emailConfig->protocol = 'smtp';
        $emailConfig->SMTPHost = $config['smtp_host'];
        $emailConfig->SMTPPort = $config['smtp_port'];
        $emailConfig->SMTPUser = $config['smtp_user'];
        $emailConfig->SMTPPass = $config['smtp_pass'];
        $emailConfig->SMTPCrypto = $config['smtp_crypto'];

        $emailService = \Config\Services::email($emailConfig);
        $emailService->setTo($email);
        $emailService->setSubject('Test - Configuration Email KISSAI SCHOOL');
        $emailService->setMessage('Ceci est un email de test pour vérifier la configuration email de KISSAI SCHOOL.');

        if ($emailService->send()) {
            return $this->response->setJSON(['success' => true, 'message' => 'Email de test envoyé avec succès']);
        } else {
            return $this->response->setJSON(['success' => false, 'message' => 'Erreur lors de l\'envoi: ' . $emailService->printDebugger(['headers'])]);
        }
    }

    /**
     * Tester la configuration SMS
     */
    public function testSMS()
    {
        $phone = $this->request->getPost('test_phone');
        
        if (empty($phone)) {
            return $this->response->setJSON(['success' => false, 'message' => 'Numéro de téléphone requis']);
        }

        // Récupérer la configuration actuelle
        $config = $this->getSettings('sms');
        
        if (!$config) {
            return $this->response->setJSON(['success' => false, 'message' => 'Configuration SMS non trouvée']);
        }

        $message = "Test - Configuration SMS KISSAI SCHOOL\nCeci est un SMS de test pour vérifier la configuration.";
        
        // Envoyer le SMS selon le fournisseur
        $result = $this->sendTestSMS($phone, $message, $config);
        
        return $this->response->setJSON($result);
    }

    /**
     * Tester la configuration WhatsApp
     */
    public function testWhatsApp()
    {
        $phone = $this->request->getPost('test_phone');
        
        if (empty($phone)) {
            return $this->response->setJSON(['success' => false, 'message' => 'Numéro de téléphone requis']);
        }

        // Récupérer la configuration actuelle
        $config = $this->getSettings('whatsapp');
        
        if (!$config) {
            return $this->response->setJSON(['success' => false, 'message' => 'Configuration WhatsApp non trouvée']);
        }

        $message = "Test - Configuration WhatsApp KISSAI SCHOOL\nCeci est un message de test pour vérifier la configuration.";
        
        // Envoyer le message WhatsApp selon le fournisseur
        $result = $this->sendTestWhatsApp($phone, $message, $config);
        
        return $this->response->setJSON($result);
    }

    /**
     * Obtenir les fournisseurs Email
     */
    private function getEmailProviders()
    {
        return [
            'gmail' => [
                'name' => 'Gmail SMTP',
                'description' => 'Service email de Google',
                'fields' => ['smtp_user', 'smtp_pass']
            ],
            'office365' => [
                'name' => 'Office 365',
                'description' => 'Service email Microsoft Office 365',
                'fields' => ['smtp_user', 'smtp_pass']
            ],
            'outlook' => [
                'name' => 'Outlook/Hotmail',
                'description' => 'Service email de Microsoft',
                'fields' => ['smtp_user', 'smtp_pass']
            ],
            'custom' => [
                'name' => 'Serveur SMTP personnalisé',
                'description' => 'Configuration SMTP personnalisée',
                'fields' => ['smtp_host', 'smtp_port', 'smtp_crypto', 'smtp_user', 'smtp_pass']
            ]
        ];
    }

    /**
     * Obtenir les fournisseurs SMS
     */
    private function getSMSProviders()
    {
        return [
            'textlocal' => [
                'name' => 'TextLocal',
                'description' => 'Service SMS gratuit pour les tests',
                'website' => 'https://www.textlocal.in/',
                'fields' => ['api_key']
            ],
            'twilio' => [
                'name' => 'Twilio',
                'description' => 'Service SMS professionnel',
                'website' => 'https://www.twilio.com/',
                'fields' => ['account_sid', 'auth_token', 'phone_number']
            ],
            'msg91' => [
                'name' => 'MSG91',
                'description' => 'Service SMS international',
                'website' => 'https://msg91.com/',
                'fields' => ['api_key']
            ]
        ];
    }

    /**
     * Obtenir les fournisseurs WhatsApp
     */
    private function getWhatsAppProviders()
    {
        return [
            'twilio' => [
                'name' => 'Twilio WhatsApp',
                'description' => 'Service WhatsApp via Twilio',
                'website' => 'https://www.twilio.com/whatsapp',
                'fields' => ['account_sid', 'auth_token', 'phone_number']
            ],
            'dialog360' => [
                'name' => '360dialog',
                'description' => 'Service WhatsApp Business API',
                'website' => 'https://www.360dialog.com/',
                'fields' => ['api_key', 'phone_number']
            ]
        ];
    }

    /**
     * Sauvegarder les paramètres en base
     */
    private function saveSettings($type, $data)
    {
        try {
            $pdo = new \PDO(
                'mysql:host=100.69.65.33;port=13306;dbname=lycol_db',
                'root',
                'Bateau123',
                [\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION]
            );

            // Vérifier si la configuration existe déjà
            $stmt = $pdo->prepare("SELECT id FROM system_settings WHERE setting_type = ?");
            $stmt->execute([$type]);
            $existing = $stmt->fetch();

            if ($existing) {
                // Mettre à jour
                $stmt = $pdo->prepare("UPDATE system_settings SET setting_value = ?, updated_at = ? WHERE setting_type = ?");
                $stmt->execute([json_encode($data), date('Y-m-d H:i:s'), $type]);
            } else {
                // Insérer
                $stmt = $pdo->prepare("INSERT INTO system_settings (setting_type, setting_value, created_at, updated_at) VALUES (?, ?, ?, ?)");
                $stmt->execute([$type, json_encode($data), date('Y-m-d H:i:s'), date('Y-m-d H:i:s')]);
            }

            return true;
        } catch (\PDOException $e) {
            error_log("Erreur sauvegarde paramètres: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Récupérer les paramètres depuis la base
     */
    private function getSettings($type)
    {
        try {
            $pdo = new \PDO(
                'mysql:host=100.69.65.33;port=13306;dbname=lycol_db',
                'root',
                'Bateau123',
                [\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION]
            );

            $stmt = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_type = ?");
            $stmt->execute([$type]);
            $result = $stmt->fetch();

            return $result ? json_decode($result['setting_value'], true) : null;
        } catch (\PDOException $e) {
            error_log("Erreur récupération paramètres: " . $e->getMessage());
            return null;
        }
    }

    /**
     * Envoyer un SMS de test
     */
    private function sendTestSMS($phone, $message, $config)
    {
        switch ($config['provider']) {
            case 'textlocal':
                $apiUrl = 'https://api.textlocal.in/send/';
                $data = [
                    'apikey' => $config['api_key'],
                    'numbers' => $phone,
                    'message' => $message,
                    'sender' => $config['sender_name']
                ];
                break;
            case 'twilio':
                $apiUrl = "https://api.twilio.com/2010-04-01/Accounts/{$config['account_sid']}/Messages.json";
                $data = [
                    'From' => $config['phone_number'],
                    'To' => $phone,
                    'Body' => $message
                ];
                break;
            default:
                return ['success' => false, 'message' => 'Fournisseur SMS non supporté'];
        }

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $apiUrl);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        if ($config['provider'] === 'twilio') {
            curl_setopt($ch, CURLOPT_USERPWD, "{$config['account_sid']}:{$config['auth_token']}");
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/x-www-form-urlencoded']);
        }

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($config['provider'] === 'twilio' && $httpCode === 201) {
            return ['success' => true, 'message' => 'SMS de test envoyé avec succès'];
        } elseif ($config['provider'] === 'textlocal' && $httpCode === 200) {
            return ['success' => true, 'message' => 'SMS de test envoyé avec succès'];
        } else {
            return ['success' => false, 'message' => 'Erreur lors de l\'envoi: ' . $response];
        }
    }

    /**
     * Envoyer un message WhatsApp de test
     */
    private function sendTestWhatsApp($phone, $message, $config)
    {
        switch ($config['provider']) {
            case 'twilio':
                $apiUrl = "https://api.twilio.com/2010-04-01/Accounts/{$config['account_sid']}/Messages.json";
                $data = [
                    'From' => "whatsapp:{$config['phone_number']}",
                    'To' => "whatsapp:$phone",
                    'Body' => $message
                ];
                break;
            case 'dialog360':
                $apiUrl = "https://waba-v2.360dialog.io/messages";
                $data = [
                    'to' => $phone,
                    'type' => 'text',
                    'text' => ['body' => $message]
                ];
                break;
            default:
                return ['success' => false, 'message' => 'Fournisseur WhatsApp non supporté'];
        }

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $apiUrl);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $config['provider'] === 'dialog360' ? json_encode($data) : http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        if ($config['provider'] === 'twilio') {
            curl_setopt($ch, CURLOPT_USERPWD, "{$config['account_sid']}:{$config['auth_token']}");
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/x-www-form-urlencoded']);
        } elseif ($config['provider'] === 'dialog360') {
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json',
                'D360-API-KEY: ' . $config['api_key']
            ]);
        }

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if (($config['provider'] === 'twilio' && $httpCode === 201) || 
            ($config['provider'] === 'dialog360' && $httpCode === 200)) {
            return ['success' => true, 'message' => 'Message WhatsApp de test envoyé avec succès'];
        } else {
            return ['success' => false, 'message' => 'Erreur lors de l\'envoi: ' . $response];
        }
    }
}
