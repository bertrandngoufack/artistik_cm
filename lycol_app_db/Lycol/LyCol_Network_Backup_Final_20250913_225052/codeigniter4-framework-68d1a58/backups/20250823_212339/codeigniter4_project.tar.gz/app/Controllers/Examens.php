<?php

namespace App\Controllers;

use App\Models\ExamModel;
use App\Models\GradeModel;
use App\Models\StudentModel;

class Examens extends BaseController
{
    protected $examModel;
    protected $gradeModel;
    protected $studentModel;

    public function __construct()
    {
        $this->examModel = new ExamModel();
        $this->gradeModel = new GradeModel();
        $this->studentModel = new StudentModel();
    }

    public function index()
    {
        $data = [
            'title' => 'Module Examens',
            'stats' => $this->getExamStats(),
            'recentExams' => $this->examModel->getRecentExams(10)
        ];

        return view('admin/examens/dashboard', $data);
    }

    public function exams()
    {
        $data = [
            'title' => 'Gestion des Examens',
            'exams' => $this->examModel->getExamsPaginated(),
            'pager' => $this->examModel->getExamsPager()
        ];

        return view('admin/examens/exams', $data);
    }

    public function createExam()
    {
        $data = [
            'title' => 'Nouvel Examen'
        ];

        return view('admin/examens/create_exam', $data);
    }

    public function storeExam()
    {
        $rules = [
            'name' => 'required|min_length[2]|max_length[100]',
            'type' => 'required|in_list[CONTROL,EXAM,COMPOSITION]',
            'class_id' => 'required|integer',
            'subject_id' => 'required|integer',
            'exam_date' => 'required|valid_date',
            'total_marks' => 'required|numeric|greater_than[0]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $examData = [
            'name' => $this->request->getPost('name'),
            'type' => $this->request->getPost('type'),
            'class_id' => $this->request->getPost('class_id'),
            'subject_id' => $this->request->getPost('subject_id'),
            'exam_date' => $this->request->getPost('exam_date'),
            'total_marks' => $this->request->getPost('total_marks'),
            'status' => 'SCHEDULED'
        ];

        if ($this->examModel->insert($examData)) {
            return redirect()->to('admin/examens/exams')->with('success', 'Examen créé avec succès');
        } else {
            return redirect()->back()->withInput()->with('error', 'Erreur lors de la création');
        }
    }

    public function editExam($id)
    {
        $exam = $this->examModel->find($id);
        
        if (!$exam) {
            return redirect()->to('admin/examens/exams')->with('error', 'Examen non trouvé');
        }

        $data = [
            'title' => 'Modifier l\'Examen',
            'exam' => $exam
        ];

        return view('admin/examens/edit_exam', $data);
    }

    public function updateExam($id)
    {
        $rules = [
            'name' => 'required|min_length[2]|max_length[100]',
            'type' => 'required|in_list[CONTROL,EXAM,COMPOSITION]',
            'class_id' => 'required|integer',
            'subject_id' => 'required|integer',
            'exam_date' => 'required|valid_date',
            'total_marks' => 'required|numeric|greater_than[0]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $examData = [
            'name' => $this->request->getPost('name'),
            'type' => $this->request->getPost('type'),
            'class_id' => $this->request->getPost('class_id'),
            'subject_id' => $this->request->getPost('subject_id'),
            'exam_date' => $this->request->getPost('exam_date'),
            'total_marks' => $this->request->getPost('total_marks')
        ];

        if ($this->examModel->update($id, $examData)) {
            return redirect()->to('admin/examens/exams')->with('success', 'Examen mis à jour avec succès');
        } else {
            return redirect()->back()->withInput()->with('error', 'Erreur lors de la mise à jour');
        }
    }

    public function deleteExam($id)
    {
        if ($this->examModel->delete($id)) {
            return redirect()->to('admin/examens/exams')->with('success', 'Examen supprimé avec succès');
        } else {
            return redirect()->to('admin/examens/exams')->with('error', 'Erreur lors de la suppression');
        }
    }

    public function grades()
    {
        $data = [
            'title' => 'Gestion des Notes',
            'exams' => $this->examModel->getCompletedExams()
        ];

        return view('admin/examens/grades', $data);
    }

    public function enterGrades($examId)
    {
        $exam = $this->examModel->find($examId);
        
        if (!$exam) {
            return redirect()->to('admin/examens/grades')->with('error', 'Examen non trouvé');
        }

        $data = [
            'title' => 'Saisie des Notes',
            'exam' => $exam,
            'students' => $this->studentModel->getStudentsByClass($exam['class_id']),
            'grades' => $this->gradeModel->getGradesByExam($examId)
        ];

        return view('admin/examens/enter_grades', $data);
    }

    public function storeGrades()
    {
        $examId = $this->request->getPost('exam_id');
        $grades = $this->request->getPost('grades');

        foreach ($grades as $studentId => $grade) {
            $gradeData = [
                'exam_id' => $examId,
                'student_id' => $studentId,
                'marks_obtained' => $grade['marks'],
                'percentage' => ($grade['marks'] / 100) * 100,
                'recorded_by' => session()->get('user_id')
            ];

            $this->gradeModel->insert($gradeData);
        }

        return redirect()->to('admin/examens/grades')->with('success', 'Notes enregistrées avec succès');
    }

    public function reportCards()
    {
        $data = [
            'title' => 'Bulletins de Notes',
            'classes' => $this->studentModel->getActiveClasses()
        ];

        return view('admin/examens/report_cards', $data);
    }

    public function generateReportCards()
    {
        $classId = $this->request->getPost('class_id');
        $examId = $this->request->getPost('exam_id');

        $data = [
            'title' => 'Bulletins Générés',
            'class_id' => $classId,
            'exam_id' => $examId,
            'students' => $this->studentModel->getStudentsByClass($classId),
            'grades' => $this->gradeModel->getGradesByExam($examId)
        ];

        return view('admin/examens/generated_report_cards', $data);
    }

    public function statistics()
    {
        $data = [
            'title' => 'Statistiques des Examens',
            'stats' => $this->getExamStatistics()
        ];

        return view('admin/examens/statistics', $data);
    }

    private function getExamStats()
    {
        return [
            'totalExams' => $this->examModel->countAllResults(),
            'completedExams' => $this->examModel->getCompletedExams()->count(),
            'pendingExams' => $this->examModel->where('status', 'SCHEDULED')->countAllResults()
        ];
    }

    private function getExamStatistics()
    {
        return [
            'averageScores' => $this->gradeModel->getAverageScores(),
            'passRates' => $this->gradeModel->getPassRates(),
            'topStudents' => $this->gradeModel->getTopStudents()
        ];
    }
}




