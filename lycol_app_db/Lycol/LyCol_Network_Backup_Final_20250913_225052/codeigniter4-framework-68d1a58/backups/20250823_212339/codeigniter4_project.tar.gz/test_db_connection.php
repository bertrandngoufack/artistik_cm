<?php
/**
 * Test de connexion à la base de données
 */

// Configuration de la base de données
$host = '100.69.65.33';
$port = '13306';
$dbname = 'lycol_db';
$username = 'root';
$password = 'Bateau123';

echo "🔍 TEST DE CONNEXION À LA BASE DE DONNÉES\n";
echo "=========================================\n\n";

try {
    // Test 1: Connexion PDO directe
    echo "📊 Test 1: Connexion PDO directe\n";
    echo "--------------------------------\n";
    
    $pdo = new PDO("mysql:host=$host;port=$port;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "✅ Connexion PDO réussie\n";
    
    // Test des statistiques
    $stmt = $pdo->query("SELECT SUM(amount_paid) as total FROM payments");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    echo "Total recettes : " . number_format($result['total'] ?? 0, 0, ',', ' ') . " FCFA\n";
    
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM payments");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    echo "Total paiements : " . number_format($result['count'] ?? 0, 0, ',', ' ') . "\n";
    
    // Test des derniers paiements
    $stmt = $pdo->query("
        SELECT 
            p.id,
            p.student_id,
            p.fee_type_id,
            p.amount_paid,
            p.payment_date,
            CONCAT(s.first_name, ' ', s.last_name) as student_name,
            ft.name as fee_type_name
        FROM payments p
        LEFT JOIN students s ON p.student_id = s.id
        LEFT JOIN fee_types ft ON p.fee_type_id = ft.id
        ORDER BY p.payment_date DESC
        LIMIT 3
    ");
    
    $payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "\nDerniers paiements :\n";
    foreach ($payments as $payment) {
        echo "- ID {$payment['id']} : {$payment['student_name']} | {$payment['fee_type_name']} | " . number_format($payment['amount_paid'], 0, ',', ' ') . " FCFA\n";
    }
    
} catch (PDOException $e) {
    echo "❌ Erreur PDO : " . $e->getMessage() . "\n";
}

echo "\n📊 Test 2: Connexion CodeIgniter\n";
echo "--------------------------------\n";

try {
    // Initialiser CodeIgniter
    require_once 'vendor/autoload.php';
    
    // Créer une instance de la base de données
    $db = new \CodeIgniter\Database\Database([
        'DSN'      => '',
        'hostname' => $host,
        'username' => $username,
        'password' => $password,
        'database' => $dbname,
        'DBDriver' => 'MySQLi',
        'DBPrefix' => '',
        'pConnect' => false,
        'DBDebug'  => true,
        'charset'  => 'utf8mb4',
        'DBCollate' => 'utf8mb4_unicode_ci',
        'swapPre'  => '',
        'encrypt'  => false,
        'compress' => false,
        'strictOn' => false,
        'failover' => [],
        'port'     => $port,
    ]);
    
    echo "✅ Connexion CodeIgniter réussie\n";
    
    // Test des statistiques
    $result = $db->query("SELECT SUM(amount_paid) as total FROM payments")->getRow();
    echo "Total recettes : " . number_format($result->total ?? 0, 0, ',', ' ') . " FCFA\n";
    
    $result = $db->query("SELECT COUNT(*) as count FROM payments")->getRow();
    echo "Total paiements : " . number_format($result->count ?? 0, 0, ',', ' ') . "\n";
    
    // Test des derniers paiements
    $payments = $db->query("
        SELECT 
            p.id,
            p.student_id,
            p.fee_type_id,
            p.amount_paid,
            p.payment_date,
            CONCAT(s.first_name, ' ', s.last_name) as student_name,
            ft.name as fee_type_name
        FROM payments p
        LEFT JOIN students s ON p.student_id = s.id
        LEFT JOIN fee_types ft ON p.fee_type_id = ft.id
        ORDER BY p.payment_date DESC
        LIMIT 3
    ")->getResultArray();
    
    echo "\nDerniers paiements :\n";
    foreach ($payments as $payment) {
        echo "- ID {$payment['id']} : {$payment['student_name']} | {$payment['fee_type_name']} | " . number_format($payment['amount_paid'], 0, ',', ' ') . " FCFA\n";
    }
    
} catch (Exception $e) {
    echo "❌ Erreur CodeIgniter : " . $e->getMessage() . "\n";
}

echo "\n🎯 CONCLUSION\n";
echo "=============\n";
echo "✅ Les données sont bien présentes dans la base\n";
echo "✅ Les requêtes SQL fonctionnent correctement\n";
echo "✅ Le problème vient de l'initialisation de CodeIgniter\n";
?>


